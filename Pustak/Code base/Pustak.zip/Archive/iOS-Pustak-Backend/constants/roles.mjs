const roles = {
    SA: "Super Admin",
    LA: "Library Admin",
    LB: "Librarian",
    MB: "Member"
}
export default roles;

