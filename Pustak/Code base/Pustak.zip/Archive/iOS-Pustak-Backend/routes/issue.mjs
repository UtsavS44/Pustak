import express from "express"
import { issuesCollection, libraryCollection } from "../controllers/database.mjs"
import { keyVerifier } from "../Keys/index.mjs"
import tokenVerifier from "../middleware/tokenVerifier.mjs"
import roles from "../constants/roles.mjs"

const router = express.Router();
router.post("/create", tokenVerifier([roles.MB]), (req, res) => {
    try {
        const requiredKeys = [
            "id",
            "bookId",
            "startDate",
            "endDate",
            "userId",
            "issueStatus",
            "libraryId",
            "returned"
        ]
        const requestKeys = Object.keys(req.body)
        keyVerifier(requestKeys, requiredKeys)

        const body = req.body
        let payLoad = {
            ...body
        }

        issuesCollection.insertOne(payLoad).then((e) => {
            libraryCollection.updateOne(
                {
                    id: body.libraryId,
                    "books.id": body.bookId
                },
                {
                    $inc: {
                        "books.$.qty": -1,
                    }
                }
            ).then((e) => {
                console.log(body)
                res.status(200).json({ message: "Quantity updated", issue: body })
            })
        }).catch((err) => {
            res.status(500).json({ message: "Server error" })
        })
    } catch (error) {
        res.status(400).json({ message: "Bad request" })
    }
})

// router.get("/member", tokenVerifier([roles.MB]), (req, res) => {
//     try {
//         const uId = req.query.uId
//         const libId = req.query.libId
//         if (!uId) {
//             throw new Error()
//         }

//         issuesCollection.find({ userId: uId }).toArray().then((e) => {
//             if (e) {
//                 res.status(200).json({ message: "Member issues fetched", issues: e });
//             }
//             else {
//                 res.status(404).json({ message: "User Not found" });
//             }
//         })

//     } catch {
//         res.status(400).json({ message: "Bad request member issue" })
//     }
// })

router.get("/member", tokenVerifier([roles.MB]), (req, res) => {
    try {
        const uId = req.query.uId;
        const libId = req.query.lId;
        if (!uId) {
            throw new Error();
        }

        issuesCollection
            .aggregate([
                { $match: { $and: [{ userId: uId }, { libraryId: libId }] } },
                {
                    $lookup: {
                        from: "pustak-libraries",
                        localField: "libraryId",
                        foreignField: "id",
                        as: "libraryData",
                    },
                },
                { $unwind: "$libraryData" },
                {
                    $project: {
                        _id: 0,
                        id: "$id",
                        book: {
                            $arrayElemAt: [
                                {
                                    $filter: {
                                        input: "$libraryData.books",
                                        as: "book",
                                        cond: { $eq: ["$$book.id", "$bookId"] },
                                    },
                                },
                                0,
                            ],
                        },
                        issueStatus: "$issueStatus",
                        returned: "$returned",
                    },
                },
                { $match: { book: { $ne: null } } },
            ])
            .toArray()
            .then((e) => {
                if (e) {
                    res.status(200).json({ message: "Issues fetched for member", issuedBooks: e });
                } else {
                    res.status(404).json({ message: "Not found issue fetch member" });
                }
            });
    } catch (error) {
        res.status(400).json({ message: "Bad request issue fetch member" });
    }
});

// router.get("/all", tokenVerifier([roles.LB]), (req, res) => {
//     try {
//         const libId = req.query.q;
//         if (!libId) {
//             throw new Error()
//         }

//         issuesCollection
//             .find({ libraryId: libId })
//             .toArray()
//             .then((e) => {
//                 if (e) {
//                     res.status(200).json({ message: "Issues fetched", issues: e })
//                 }
//                 else {
//                     res.status(404).json({ message: "issue not found" });
//                 }
//             })
//     }
//     catch {
//         res.status(400).json({ message: "Bad request issue all" });
//     }
// })

router.get("/all", tokenVerifier([roles.LB]), (req, res) => {
    try {
        const libId = req.query.q;
        if (!libId) {
            throw new Error();
        }

        issuesCollection
            .aggregate([
                { $match: { libraryId: libId } },
                {
                    $lookup: {
                        from: "pustak-libraries",
                        localField: "libraryId",
                        foreignField: "id",
                        as: "libraryData",
                    },
                },
                { $unwind: "$libraryData" },
                {
                    $lookup: {
                        from: "pustak-users",
                        localField: "userId",
                        foreignField: "id",
                        as: "userData",
                    },
                },
                { $unwind: "$userData" },
                { $unset: ["userData.password", "userData._id"] },
                {
                    $project: {
                        _id: 0,
                        id: "$id",
                        user: "$userData",
                        book: {
                            $arrayElemAt: [
                                {
                                    $filter: {
                                        input: "$libraryData.books",
                                        as: "book",
                                        cond: { $eq: ["$$book.id", "$bookId"] },
                                    },
                                },
                                0,
                            ],
                        },
                        issueStatus: "$issueStatus",
                        returned: "$returned",
                    },
                },
                { $match: { book: { $ne: null } } },
            ])
            .toArray()
            .then((e) => {
                if (e) {
                    res.status(200).json({ message: "OK", issueBooks: e });
                } else {
                    res.status(404).json({ message: "Not found" });
                }
            });
    } catch (err) {
        console.log(err);
        res.status(400).json({ message: "Bad request" });
    }
});
router.post("/action", tokenVerifier([roles.LB]), (req, res) => {
    try {
        const requiredKeys = ["id", "status"]
        const requestKeys = Object.keys(req.body)
        console.log(requestKeys, requiredKeys)

        keyVerifier(requestKeys, requiredKeys)

        issuesCollection.updateOne(
            { id: req.body.id },
            { $set: { issueStatus: req.body.status } }
        )
            .then((e) => {
                res.status(200).json({ message: "issue action successful" })
            })
            .catch((err) => {
                res.status(500).json({ message: "Server error" })
            })
    } catch (error) {
        res.status(400).json({ message: "Bad request issue approve" })
    }
})

router.post("/cancel", tokenVerifier([roles.MB]), (req, res) => {
    try {
        const requiredKeys = ["id"]
        const requestKeys = Object.keys(req.body);

        keyVerifier(requestKeys, requiredKeys)
        const id = req.body.id

        issuesCollection.deleteOne({ id: id })
            .then((e) => {
                res.status(200).json({ message: "Issue deletion successfull" })
            })
            .catch((err) => {
                res.status(500).json({ message: "Server error" });
            })
    } catch {
        res.status(400).json({ message: "Bad request issue cancel" })
    }
})
router.post("/return", tokenVerifier([roles.LB]), (req, res) => {
    try {
        const id = req.body.id
        if (!id) {
            throw new Error()
        }
        issuesCollection.updateOne(
            { id: id },
            {
                $set: { returned: true }
            }
        ).then((e) => {
            if (e.modifiedCount > 0) {
                res.status(200).json({ message: "Issue returned" })
            }
        })
    } catch (error) {
        res.status(400).json({ message: "Bad request issue return" })
    }
})


export default router;