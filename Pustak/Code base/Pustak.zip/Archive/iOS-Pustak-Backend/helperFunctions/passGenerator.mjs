export const libraryAdminPassword =()=>
{
    return "adminhabibi"
}
export const librarianPassword = ()=>{
    return "librarianhabibi"
}