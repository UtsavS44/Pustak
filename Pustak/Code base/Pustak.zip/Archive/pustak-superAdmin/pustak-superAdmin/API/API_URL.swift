//
//  API_URL.swift
//  pustak-superAdmin
//
//  Created by Abhay(IOS) on 02/06/24.
//

import Foundation

let apiURL = "http://localhost:7070/"
