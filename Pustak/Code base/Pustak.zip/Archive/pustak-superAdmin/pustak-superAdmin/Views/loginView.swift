//
//  loginView.swift
//  pustak-superAdmin
//
//  Created by Abhay(IOS) on 01/06/24.
//

import SwiftUI

struct loginView: View {
    @EnvironmentObject var networkManage: AuthenticationNetwork
    @EnvironmentObject var sessionManager: SessionManager
    @State private var showingLogoutAlert = false
    @State private var navigateToInitialView: Bool? = false
    @State private var key: String = ""
    @State private var isPresented: Bool = false
    @State private var isWrong: Bool = false
   
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    ZStack {
                        Circle()
                            .fill(buttonBrownGradient)
                            .frame(width: 150, height: 150)
                            .shadow(radius: 10)
                        
                        Image(systemName: "person.crop.circle.fill")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            .foregroundColor(.white)
                    }
                    
                    VStack(alignment: .center, spacing: 10) {
                        Text("Welcome Super Admin")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.primary)
                    }
                    .padding()
                    
                    VStack(alignment: .leading) {
                        SecureField("Key", text: $key)
                            .padding(12)
                            .background(Color(.systemGray6))
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(.separator), lineWidth: 1)
                            )
                    }
                    .padding(.horizontal, 16)
                    
                    VStack {
                        Button(action: {
                            networkManage.isLoading = true
                            
                            Task {
                                do {
                                    try await networkManage.validateSuperAdmin(with: key)
                                    DispatchQueue.main.async {
                                        if networkManage.isError {
                                            isPresented = true
                                            key = ""
                                        } else {
                                            guard let token = UserDefaults.standard.object(forKey: "token") as? String else { return }
                                            sessionManager.token = token
                                            sessionManager.isAuthenticated = true
                                        }
                                    }
                                } catch {
                                    // Handle error appropriately
                                }
                            }
                        }) {
                            if networkManage.isLoading {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(Color.customBrown2)
                                    .cornerRadius(12)
                            } else {
                                Text("Proceed")
                                    .frame(maxWidth: .infinity)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background((isBtnDisabled() || networkManage.isLoading) ? Color.gray : Color.customBrown2)
                                    .cornerRadius(12)
                            }
                        }
                        .padding(.horizontal, 16)
                        .disabled(isBtnDisabled() || networkManage.isLoading)
                    }
                    .padding(.top, 20)
                    
                    if networkManage.isError {
                        Text("Wrong Key")
                            .foregroundColor(.red)
                            .padding(.top, 10)
                    }
                }
                .padding(.top, 20)
            }
            .scrollIndicators(.hidden)
        }
    }
    
    func isBtnDisabled() -> Bool {
        return key.isEmpty || key.count < 4
    }
}



//
//#Preview {
//    loginView()
//}
