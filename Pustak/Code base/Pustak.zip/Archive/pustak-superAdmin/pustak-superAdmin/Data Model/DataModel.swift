//
//  DataModel.swift
//  pustak-superAdmin
//
//  Created by Abhay(IOS) on 02/06/24.
//

import Foundation

enum Role: String,Codable,CaseIterable
{
    case libraryAdmin = "Library Admin"
}
enum Domain:String,CaseIterable,Codable{
    case infosys = "chitkara.edu.in"
}

struct LibraryAdmin: Codable, Identifiable, Comparable{
    let id: UUID
    let name: String
    let email: String
    let personalEmail: String
    let phone: String
    let role: Role
    let libraries: [UUID]
    let librarians: [UUID]
    let timestamp: Date
    let domain:Domain
    
    static func < (lhs: LibraryAdmin, rhs: LibraryAdmin) -> Bool{
        return lhs.timestamp <= rhs.timestamp
    }
}
