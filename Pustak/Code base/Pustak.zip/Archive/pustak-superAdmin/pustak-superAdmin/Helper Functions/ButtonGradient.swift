//
//  ButtonGradient.swift
//  pustak-superAdmin
//
//  Created by Abhay(IOS) on 14/06/24.
//

import Foundation
import SwiftUI

let buttonBrownGradient = LinearGradient(colors: [Color.customBrown, Color.customBrown2], startPoint: .top, endPoint: .bottom)
