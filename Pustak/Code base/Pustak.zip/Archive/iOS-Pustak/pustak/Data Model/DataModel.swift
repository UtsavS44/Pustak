//
//  DataModel.swift
//  pustak
//
//  Created by Abhay(IOS) on 01/06/24.
//


import Foundation

enum Domain:String,CaseIterable,Codable{
    case infosys = "chitkara.edu.in"
}
protocol User: Codable, Identifiable{
    var id: UUID { get }
    var name: String { get }
    var email: String { get }
    var role: Role { get}
    var phone: String { get }
    var timestamp:Date {get set}
    var domain:Domain {get set}
}

enum Role: String, CaseIterable,Codable{
    case libraryAdmin = "Library Admin"
    case librarian = "Librarian"
    case member = "Member"
}


enum Genre: String, CaseIterable,Codable{
    case fiction = "Fiction"
    case nonFiction = "Non-Fiction"
    case comedy = "Comedy"
    case fantasy = "Fantasy"
    case scienceFiction = "Science Fiction"
    case mysteryAndThriller = "Mystery & Thriller"
    case romance = "Romance"
    case historical = "Historical"
}

struct Librarian: Identifiable,Codable,User{
    let id:UUID
    let role: Role
    var name: String
    var email: String
    var admin: UUID
    let assignedLibrary : UUID
    let phone : String
    let personalEmail: String
    var timestamp:Date
    var domain:Domain
    
//    static func < (lhs:Librarian,rhs:Librarian)->Bool
//    {
//        return lhs.timestamp < rhs.timestamp
//    }
}

struct LibraryAdmin: Identifiable,Codable,User{
    let id: UUID
    let role:Role
    let name: String
    let email: String
    let phone: String
    let libraries: [UUID]
    let librarians: [UUID]
    var timestamp:Date
    var domain:Domain
    
//    static func < (lhs:LibraryAdmin,rhs:LibraryAdmin)->Bool
//    {
//        return lhs.timestamp < rhs.timestamp
//    }
}

struct Member: Identifiable,Codable,User{
    let id:UUID
    let role: Role
    let name: String
    let email: String
    let phone: String
    var selectedLibrary:UUID?
    var timestamp:Date
    var domain:Domain
    
//    static func < (lhs:Member,rhs:Member)->Bool
//    {
//        return lhs.timestamp < rhs.timestamp
//    }
}
struct SetLibrary:Codable{
    let userId:UUID
    let libraryId:UUID
}
struct AddToWishlist:Codable{
    let book:UUID
    let userId:UUID
    let libraryId:UUID
}
struct MemberSignUp: Codable{
    let user:Member
    let password:String
    let timestamp:Date
    static func < (lhs:MemberSignUp,rhs:MemberSignUp)->Bool
    {
        return lhs.timestamp < rhs.timestamp
    }
}
struct Fine: Identifiable{
    let id = UUID()
    let userId: UUID
    let bookId: UUID
    let finePaid: Bool
    let amount: String
    let libraryId: UUID
}

enum IssueStatus:String,CaseIterable,Codable{
    case pending = "Pending"
    case approved = "Approved"
    case rejected = "Rejected"
}
struct Issues: Identifiable,Codable{
    let id:UUID
    let bookId: UUID
    let startDate: Date
    let endDate:Date
    let userId: UUID
    let issueStatus: IssueStatus
    let libraryId: UUID
    let returned:Bool
    let timestamp:Date
//    static func < (lhs:Issues,rhs:Issues)->Bool
//    {
//        return lhs.timestamp < rhs.timestamp
//    }
}

struct Library: Identifiable, Codable{
    let id:UUID
    var librarianAssigned: UUID?
    let libraryAdmin: UUID
    let libraryName: String
    let libraryContact: String
    let address: String
    let libraryEmail: String
    let books: [Books]
    let timestamp:Date
    var domain:Domain
    
    enum CodingKeys: String, CodingKey {
        case id
        case librarianAssigned
        case libraryAdmin
        case libraryName
        case libraryContact
        case address
        case libraryEmail = "email"
        case books
        case timestamp
        case domain
    }
    
    init(adminID: UUID, name: String, contact: String, address: String, email: String, libraryId id: UUID = UUID(), librarianAssigned libAss: UUID? = nil,time timestamp: Date = Date(),domain:Domain = .infosys){
        self.id = id
        if let libAss = libAss {
            self.librarianAssigned = libAss
        }else{
            librarianAssigned = nil
        }
        libraryAdmin = adminID
        libraryName = name
        libraryContact = contact
        self.address = address
        books =  []
        libraryEmail = email
        self.timestamp = timestamp
        self.domain = domain
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        librarianAssigned = try container.decodeIfPresent(UUID.self, forKey: .librarianAssigned)
        libraryAdmin = try container.decode(UUID.self, forKey: .libraryAdmin)
        libraryName = try container.decode(String.self, forKey: .libraryName)
        libraryContact = try container.decode(String.self, forKey: .libraryContact)
        address = try container.decode(String.self, forKey: .address)
        libraryEmail = try container.decode(String.self, forKey: .libraryEmail)
        books = try container.decode([Books].self, forKey: .books)
        timestamp = try container.decode(Date.self, forKey: .timestamp)
        domain = try container.decode(Domain.self, forKey: .domain)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encodeIfPresent(librarianAssigned, forKey: .librarianAssigned)
        try container.encode(libraryAdmin, forKey: .libraryAdmin)
        try container.encode(libraryName, forKey: .libraryName)
        try container.encode(libraryContact, forKey: .libraryContact)
        try container.encode(address, forKey: .address)
        try container.encode(libraryEmail, forKey: .libraryEmail)
        try container.encode(books, forKey: .books)
        try container.encode(timestamp,forKey: .timestamp)
        try container.encode(domain, forKey: .domain)
    }
//    static func < (lhs: Library, rhs: Library) -> Bool {
//        return lhs.timestamp < rhs.timestamp
//    }
}

struct Books: Identifiable,Codable{
    let id:UUID
    let ISBN: String
    let title: String
    let yearPublished: String
    let author: String
    let publisher: String
    let genre: Genre
    let nosPages: String
    let libraryId: UUID
    let qty: Int
    let description:String
    let timestamp:Date
    
//    static func < (lhs:Books,rhs:Books)->Bool
//    {
//        return lhs.timestamp < rhs.timestamp
//    }
}

struct LibraryDeletionStructure:Codable{
    let libraryId:UUID
    let librarianId:UUID
}

struct MemberIssueBook: Codable, Identifiable {
    let id: UUID
    let book: Books
    var issueStatus: IssueStatus
    var returned: Bool
}

struct LibrarianIssueBook: Codable, Identifiable {
    var id: UUID
    var user: Member
    var book: Books
    var issueStatus:IssueStatus
    var returned: Bool
}
struct ActionManager:Codable{
    var id:UUID
    var status:IssueStatus
}
