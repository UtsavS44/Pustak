//
//  ButtonGradient.swift
//  pustak
//
//  Created by Abhay(IOS) on 13/06/24.
//

import Foundation
import SwiftUI

let buttonBrownGradient = LinearGradient(colors: [Color.customBrown, Color.customBrown2], startPoint: .top, endPoint: .bottom)
