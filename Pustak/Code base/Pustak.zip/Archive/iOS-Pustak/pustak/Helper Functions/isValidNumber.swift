//
//  isValidNumber.swift
//  pustak
//
//  Created by Abhay(IOS) on 04/06/24.
//

import Foundation

import Foundation

func isValidNumber(_ phone: String) -> Bool{
    return phone.count != 10 ? true : false
}
