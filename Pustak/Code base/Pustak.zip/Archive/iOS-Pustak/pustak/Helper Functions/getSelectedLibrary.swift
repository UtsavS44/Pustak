//
//  getSelectedLibrary.swift
//  pustak
//
//  Created by Abhay(IOS) on 13/06/24.
//

import Foundation

func getSelectedLibrary()->UUID{
    guard let libId = UserDefaults.standard.object(forKey: "selectedLibrary") as? String,
          let id = UUID(uuidString: libId) else {return UUID()}
    return id
}
