//
//  isValidText.swift
//  pustak
//
//  Created by Abhay(IOS) on 05/06/24.
//

import Foundation
import SwiftUI

//func isValidText( _ inputText:Binding<String>) -> Bool
//{
//    inputText = inputText.wrappedValue.trimmingCharacters(in: .whitespacesAndNewlines)
//    return inputText.wrappedValue.isEmpty
//}
//private func trimInputText() {
//        inputText = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
//    }

