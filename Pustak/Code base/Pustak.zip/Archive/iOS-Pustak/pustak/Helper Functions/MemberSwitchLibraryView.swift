//
//  MemberSwitchLibraryView.swift
//  pustak
//
//  Created by Abhay(IOS) on 13/06/24.
//

import SwiftUI

struct MemberSwitchLibraryView: View {
    @EnvironmentObject var domainLibraryManager:FetchLibrariesWithDomain
    @EnvironmentObject var profileManager:ProfileManager
    @EnvironmentObject var bookFetchManager: LibrarianFetchBookManager
    @StateObject var setLibrary = SetSelectedLibrary()
    @Environment(\.dismiss) var dismiss
    @State var selectedLibrary:UUID? = nil
    var body: some View {
        NavigationStack{
            ScrollView{
                VStack{
                    ForEach(domainLibraryManager.viewableLibraries){ library in
                        LibrarySelectionCard(library: library, isSelected: library.id == selectedLibrary)
                            .onTapGesture{
                                selectedLibrary = library.id
                            }
                    }
                }
                .padding()
                
                VStack{
                    if selectedLibrary != nil{
                        Button(action:{
                            let set = SetLibrary(userId: profileManager.user!.id, libraryId: selectedLibrary!)
                            UserDefaults.standard.set(selectedLibrary!.uuidString, forKey: "selectedLibrary")
                            Task{
                                do{
                                    try await setLibrary.setSelectedLibrary(with: set)
                                    try await bookFetchManager.fetchBooks(with: set.libraryId)
                                }catch{
                                    
                                }
                                
                            }
                            guard var member = profileManager.user as? Member else {return}
                            member.selectedLibrary = selectedLibrary
                            profileManager.user = member
                            dismiss()
                        }){
                            Text("Confirm")
                        }
                        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/)
                        .frame(height: 50)
                        .background(buttonBrownGradient)
                        .foregroundStyle(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .padding(.horizontal)
                    }
                }
            }
            .navigationTitle("Choose a library")
        }
        .onAppear(perform: {
            Task{
                do{
                    try await domainLibraryManager.fetchLibraries(with: .infosys)
                }
            }
        })
        
    }
}
