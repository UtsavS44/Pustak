//
//  APINetwork.swift
//  pustak
//
//  Created by Abhay(IOS) on 31/05/24.


import Foundation
import SwiftUI

//Fetching the details from UserDefaults
class UserSession: ObservableObject{
    @Published var isAuthenticated: Bool
    @Published var role: Role
    @Published var token: String
    @Published var uId: UUID
    
    init() {
        guard let token = UserDefaults.standard.object(forKey: "token") as? String,
              let roleString = UserDefaults.standard.object(forKey: "role") as? String,
              let role = Role(rawValue: roleString),
              let uuidString = UserDefaults.standard.object(forKey: "id") as? String,
              let uId = UUID(uuidString: uuidString)
        else{
            self.isAuthenticated = false
            self.role = .member
            self.token = ""
            self.uId = UUID()
            return
        }
        
        self.role = role
        self.token = token
        self.uId = uId
        self.isAuthenticated = true
    }
}

//Verifying if token is still active
class AuthNetworkManager: ObservableObject,ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    init(){
        Task{
            do{
                guard let token = UserDefaults.standard.object(forKey: "token") as? String, token.count > 0 else {return}
                DispatchQueue.main.async{
                    self.isLoading = true
                }
                print(token)
                let _ = try await getSetData(type: "POST", endpoint: "verify",token: token)

                DispatchQueue.main.async{
                    self.isLoading = false
                }
            }catch{
                print(error)
                guard let error = error as? ErrorResponse else {return}
                //                self.isLoading = false
                self.errorHandler(error)
            }
        }
        
    }
    
    //Login the user from initial view
    func loginUser(with data: Data) async throws{
        
        do{
            let data = try await getSetData(type: "POST", endpoint: "auth/login",body: data)
            guard let data = data else {throw ErrorResponse.noData}
            
            let decodedData = try JSONDecoder().decode(AuthResponse.self, from: data)
            
            DispatchQueue.main.async{
                UserDefaults.standard.set(decodedData.token, forKey: "token")
                UserDefaults.standard.set(decodedData.role.rawValue, forKey: "role")
                UserDefaults.standard.set(decodedData.id.uuidString, forKey: "id")
            }
            
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
        
    }
    
    //Create a new account for user from SignUp view
    func signUp(with user:SignUp) async throws{
        do{
            let body = try JSONEncoder().encode(user)
            let data = try await getSetData(type: "POST", endpoint: "auth/signup",body: body)
            let decodedData = try JSONDecoder().decode(AuthResponse.self, from: data!)
            
            DispatchQueue.main.async{
                UserDefaults.standard.set(decodedData.token, forKey: "token")
                UserDefaults.standard.set(decodedData.role.rawValue, forKey: "role")
                UserDefaults.standard.set(decodedData.id.uuidString, forKey: "id")
            }
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Fetching the profile details for profile view
class ProfileManager:ObservableObject, ErrorHandling{
    @Published var user: (any User)?
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    func fetchProfile(with id:UUID) async throws{
        do{
            let data = try await getSetData(type: "GET", endpoint: "users/\(id.uuidString)",token: fetchToken())
            let decodedData = try JSONDecoder().decode(ProfileResponse.self, from: data!)
            DispatchQueue.main.async{
                self.user = decodedData.user
                self.isLoading = false
            }
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
            //            print(error)
        }
    }
}

//Fetching the libraries created by admin
class AdminManager: ObservableObject,ErrorHandling{
    @Published var libraries: [Library] = []
    @Published var isLoading = false
    @Published var isError = false
    @Published var errorMessage: String = ""
    
    func fetchLibrary(with id:UUID) async throws{
        do{
            let data = try await getSetData(type: "GET", endpoint: "library/", token:fetchToken(),queryParams: ["id":id.uuidString])
            //            print(String(data: data!, encoding: .utf8)!)
            
            let decodedData = try JSONDecoder().decode(LibraryResponse.self, from: data!)
            DispatchQueue.main.async{
                self.libraries = decodedData.libraries
                //                self.libraries.sort(by: >)
                self.isLoading = false
            }
        }catch{
            //            print(error)
            //            print("fnjsalka;snlanfl")
        }
    }
}

//Creating of Library by admin
class AdminLibraryCreation:ObservableObject,ErrorHandling{
    @Published var isLoading = false
    @Published var isError = false
    @Published var errorMessage = ""
    func createLibrary(with library:Library, of instance:AdminManager) async throws
    {
        do{
            let body = try JSONEncoder().encode(library)
            let _ = try await getSetData(type: "POST", endpoint: "library/create",token: fetchToken(),body:body)
            
            DispatchQueue.main.async{
                instance.libraries.insert(library, at: 0)
                self.isLoading = false
            }
        }
        catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Librarian account creation and assigning to library by Admin
class AdminAssignLibrarian: ObservableObject,ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func assignLibrarian(with librarian: Librarian, of instance: AdminManager) async throws {
        do{
            let body = try JSONEncoder().encode(librarian)
            let _ = try await getSetData(type:"POST", endpoint: "librarian/create", token: fetchToken(), body: body)
            
            DispatchQueue.main.async{
                let idxToUpdate = instance.libraries.firstIndex(where: {$0.id == librarian.assignedLibrary})!
                instance.libraries[idxToUpdate].librarianAssigned = librarian.id
                //                print(instance.libraries[idxToUpdate])
            }
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Update details of librarian
class AdminUpdateLibrarianManager:ObservableObject,ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func updateLibrarianDetails(with librarian:Librarian, of instance:AdminLibraryDetailManager) async throws{
        do{
            let body = try JSONEncoder().encode(librarian)
            let _ = try await getSetData(type: "POST", endpoint: "librarian/update",token: fetchToken(),body:body)
            
            DispatchQueue.main.async{
                instance.librarian = librarian
            }
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Revoking the librarian from library and deleting the librarian account
class AdminRevokeLibrarianManager:ObservableObject, ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func revokeLibrarian(with id:UUID, of instance:AdminManager, of2 instance2:AdminLibraryDetailManager) async throws{
        do{
            let _ = try await getSetData(type: "PUT", endpoint: "librarian/remove/\(id.uuidString)",token: fetchToken())
            
            DispatchQueue.main.async{
                let idxToUpdate = instance.libraries.firstIndex(where: {$0.librarianAssigned == id})!
                instance.libraries[idxToUpdate].librarianAssigned = nil
                
                instance2.librarian = nil
            }
            
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Update details of library
class AdminUpdateLibraryManager:ObservableObject, ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    func updateLibrary(with library:Library, of instance:AdminManager) async throws{
        do{
            let body = try JSONEncoder().encode(library)
            let _ = try await getSetData(type: "POST", endpoint: "library/update",token: fetchToken(),body: body)
            DispatchQueue.main.async{
                let idxToUpdate = instance.libraries.firstIndex(where: {$0.id == library.id})!
                instance.libraries[idxToUpdate] = library
                self.isLoading = false
            }
            
        }catch{
            //            print(error)
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Deleting the library from database
class AdminDeleteLibraryManager:ObservableObject,ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func deleteLibrary(libraryndLibrarianId:LibraryDeletionStructure ,of instance:AdminManager) async throws{
        do{
            let body = try JSONEncoder().encode(libraryndLibrarianId)
            let _ = try await getSetData(type: "POST", endpoint: "library/delete",token: fetchToken(),body:body)
            
            DispatchQueue.main.async{
                instance.libraries.removeAll(where:{$0.id == libraryndLibrarianId.libraryId})
                self.isLoading = false
            }
            
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Fetching library details
class AdminLibraryDetailManager: ObservableObject, ErrorHandling{
    @Published var librarian: Librarian?
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func fetchLibraryDetails(id: String) async throws {
        do{
            let data = try await getSetData(type:"GET", endpoint: "librarian/all/\(id)", token: fetchToken())
            //            print("DATA")
            //            print(String(data: data!, encoding: .utf8)!)
            let decodedData = try JSONDecoder().decode(LibraryDetailResponse.self, from: data!)
            //            print("HUIHUI")
            //            print( decodedData)
            DispatchQueue.main.async{
                self.librarian = decodedData.librarian
                self.isLoading = false
            }
        }catch{
            //            print(error)
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
        
    }
}


//Fetching the library id
class GetLibraryManager:ObservableObject, ErrorHandling{
    @Published var libraryId:String = ""
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func getLibraryId(with id:UUID) async throws{
        do{
            let data = try await getSetData(type: "GET", endpoint: "library/\(id)",token: fetchToken())
            let decodedData = try JSONDecoder().decode(LibraryIdResponse.self, from: data!)
            DispatchQueue.main.async{
                self.libraryId = decodedData.library.id.uuidString
                self.isLoading = false
            }
        }catch{
            //            print(error)
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Fetching the books of Librarian
class LibrarianFetchBookManager:ObservableObject, ErrorHandling{
    @Published var books: [Books] = []
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func fetchBooks(with id:UUID) async throws{
        do{
            let data = try await getSetData(type: "GET", endpoint: "book/all/\(id)", token: fetchToken())
            let decodedData = try JSONDecoder().decode(BooksResponse.self, from: data!)
            DispatchQueue.main.async{
                self.books = decodedData.books
                self.isLoading = false
            }
        }catch{
            guard let error  = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
    func isFav(id:UUID,wishlist:[Books])->Bool
    {
        print(wishlist.contains(where: {$0.id == id}))
        return wishlist.contains(where: {$0.id == id})
    }
    
}

//Adding a book to stock
class LibrarianAddBookManager:ObservableObject, ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func addBook(with book:Books, of instance:LibrarianFetchBookManager) async throws{
        do{
            let body = try JSONEncoder().encode(book)
            let _ = try await getSetData(type: "POST", endpoint: "book/create",token: fetchToken(),body:body)
            DispatchQueue.main.async{
                instance.books.insert(book,at:0)
                self.isLoading = false
            }
            
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
    
}

//Updating the book details of an existing book
class LibrarianUpdateBookManager:ObservableObject, ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func updateBook(with book:Books, of instance:LibrarianFetchBookManager) async throws{
        do{
            let body = try JSONEncoder().encode(book)
            let _ = try await getSetData(type: "POST", endpoint: "book/update",token: fetchToken(),body: body)
            DispatchQueue.main.async{
                let idxToUpdate = instance.books.firstIndex(where: {$0.id == book.id})!
                instance.books[idxToUpdate] = book
                self.isLoading = false
            }
            
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}


//Deleting an existing book
class LibrarianDeleteBookManager:ObservableObject,ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func deleteBook(with book:Books, of instance:LibrarianFetchBookManager) async throws{
        do{
            let body = try JSONEncoder().encode(book)
            let _ =  try await getSetData(type: "POST", endpoint: "book/remove",token: fetchToken(),body:body)
            DispatchQueue.main.async{
                let idxToUpdate = instance.books.firstIndex(where: {$0.id == book.id})!
                instance.books.remove(at: idxToUpdate)
                self.isLoading = false
            }
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Fetching all the libraries under a single domain
class FetchLibrariesWithDomain:ObservableObject,ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    @Published var viewableLibraries:[Library] = []
    func fetchLibraries(with domain:Domain) async throws{
        do{
            print("ajbhadsbjk")
            let data = try await getSetData(type: "GET", endpoint: "library/domain?q=\(domain.rawValue)", token: fetchToken())
            let decodedData = try JSONDecoder().decode(DomainLibraryResponse.self, from: data!)
            DispatchQueue.main.async{
                self.viewableLibraries = decodedData.libraries
//                print(self.viewableLibraries)
            }
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }

    }
}

//Setting the selected library for member
class SetSelectedLibrary:ObservableObject,ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func setSelectedLibrary(with set:SetLibrary) async throws{
        do{
            let body = try JSONEncoder().encode(set)
            let _ = try await getSetData(type: "POST", endpoint: "member/set-library",token: fetchToken(),body: body)
            DispatchQueue.main.async{
                
            }
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}
//Fetching the wishlist for member
class MemberGetWishlist:ObservableObject,ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    @Published var wishlist:[Books] = []
    func getWishlist(with id:UUID, library id2:UUID) async throws{
        do{
            let data = try await getSetData(type: "GET", endpoint: "member/wishlist?q=\(id)&p=\(id2)",token: fetchToken())
            let decodedData = try JSONDecoder().decode(WishlistResponse.self, from: data!)
            DispatchQueue.main.async{
                self.wishlist = decodedData.wishlist
            }
        }catch{
            print(error)
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }

    }
}


class MemberWishlistManager:ObservableObject,ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    //Adding a book to wishlist
    func addToWishlist(with wishlistItem:Books,userId:UUID,libraryId:UUID, of instance:MemberGetWishlist) async throws
    {
        do{
            let body = try JSONEncoder().encode(AddToWishlist(book: wishlistItem.id, userId: userId, libraryId: libraryId))
            let _ = try await getSetData(type: "POST", endpoint: "member/wishlist-add",token: fetchToken(),body: body)
            DispatchQueue.main.async{
                instance.wishlist.insert(wishlistItem, at: 0)
            }
        }catch{
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
    //Removing a book from wishlist
    func removeFromWishlist(with wishlistItem:Books,userId:UUID,libraryId:UUID, of instance:MemberGetWishlist) async throws
    {
        do{
            let body = try JSONEncoder().encode(AddToWishlist(book: wishlistItem.id, userId: userId, libraryId: libraryId))
            let _ = try await getSetData(type: "POST", endpoint: "member/wishlist-remove",token: fetchToken(),body: body)
            
            DispatchQueue.main.async{
                instance.wishlist.removeAll(where: {$0.id == wishlistItem.id})
            }
        }catch{
            print(error)
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Fetching all the books which have either been issued or requested by member
class GetIssueBookManager: ObservableObject,ErrorHandling{
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    @Published var isLoading: Bool = false
    @Published var issuedBooks: [MemberIssueBook] = []
    
    
    func getIssuedBooks(_ id: UUID , libraryId : UUID) async throws {
        do {
            //            let body = try JSONEncoder().encode(book)
            let data = try await getSetData(type:"GET", endpoint: "issue/member", token: fetchToken(),queryParams: ["uId": id.uuidString, "lId": libraryId.uuidString])
            let decodeData = try JSONDecoder().decode(MemberIssueBookResponse.self, from: data!)
            DispatchQueue.main.async{
                self.issuedBooks = decodeData.issuedBooks
                self.isLoading = false
            }
        } catch {
            print(error)
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
    //Checking if a particular book has been requested
    func isRequested(id:UUID,issue:[MemberIssueBook])->Bool
    {
        return issue.contains(where: {$0.book.id == id})
    }
}

//Making an issue request for a book
class MemberIssueRequestManager:ObservableObject,ErrorHandling{
    @Published var isLoading: Bool = false
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    
    func issueRequest(with issue:Issues, book: Books, of instance:GetIssueBookManager)async throws{
        do{
            let body = try JSONEncoder().encode(issue)
            let _ = try await getSetData(type: "POST", endpoint: "issue/create",token: fetchToken(),body: body)
            DispatchQueue.main.async{
                instance.issuedBooks.insert(MemberIssueBook(id: issue.id, book: book, issueStatus: issue.issueStatus, returned: issue.returned), at: 0)
                self.isLoading = false
            }
        }catch {
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Fetching all the issue requests for librarian
class LibrarianIssueRequestManager: ObservableObject,ErrorHandling{
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    @Published var isLoading: Bool = false
    @Published var books: [LibrarianIssueBook] = []
    
    func librarianIssueBookRequest(libraryID :UUID) async throws {
        do {
            //            let body = try JSONEncoder().encode(book)
            let data = try await getSetData(type:"GET", endpoint: "issue/all", token: fetchToken(),queryParams: ["q":libraryID.uuidString])
            let decodedData = try JSONDecoder().decode(LibrarianIssueResponse.self, from: data!)
            DispatchQueue.main.async{
                self.books = decodedData.issueBooks
                self.isLoading = false
            }
        } catch {
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}

//Accepting or rejecting an issue request made by a member
class IssueActionManager: ObservableObject,ErrorHandling{
    @Published var isError: Bool = false
    @Published var errorMessage: String = ""
    @Published var isLoading: Bool = false
    
    func issueActionMnager(actionManager:ActionManager, of instance:LibrarianIssueRequestManager) async throws {
        do {
            let body = try JSONEncoder().encode(actionManager)
            let _ = try await getSetData(type:"POST", endpoint: "issue/action", token: fetchToken(),body:body)
            DispatchQueue.main.async{
                let idx = instance.books.firstIndex(where: {$0.id == actionManager.id})!
                instance.books[idx].issueStatus = actionManager.status
                self.isLoading = false
            }
        } catch {
            guard let error = error as? ErrorResponse else {return}
            self.errorHandler(error)
        }
    }
}
