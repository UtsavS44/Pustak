//
//  AdminProfileView.swift
//  pustak
//
//  Created by Abhay(IOS) on 01/06/24.
//

import SwiftUI

struct AdminProfileView: View {
    @EnvironmentObject var userSession: UserSession
    @EnvironmentObject var profileManager: ProfileManager
    @StateObject var libraryFetchManager = FetchLibrariesWithDomain()
    @EnvironmentObject var bookFetchManager: LibrarianFetchBookManager
    @EnvironmentObject var getHistoryBooksManager:GetIssueBookManager
    @State var isSwitchLibraryOn = false
    var admin:LibraryAdmin?
    var librarian:Librarian?
    var member:Member?
    @State private var showingLogoutAlert = false
    var body: some View {
        if let admin = profileManager.user as? LibraryAdmin
        {
            NavigationStack {
                List{
                    HStack{
                        VStack{
                            ZStack{
                                Circle()
                                    .fill(Color.gray)
                                    .frame(width: 150, height: 150)
                                
                                Text("\(admin.name.first!)")
                                    .font(.title)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                            }
                            Text("\(admin.name)")
                                .font(.title)
                                .fontWeight(.bold)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    
                    Section{
                        DetailRow(label: "Role", value: admin.role.rawValue)
                        DetailRow(label: "Libraries", value: admin.email)
                        DetailRow(label: "Phone", value: admin.phone)
                    }
                    Section{
                        Button(action: {
                            showingLogoutAlert.toggle()
                        }) {
                            LogoutButton()
                        }
                    }
                    .alert("Are you sure you want to logout?", isPresented: $showingLogoutAlert) {
                        Button("Cancel", role: .cancel) { }
                        Button("Logout", role: .destructive) {
                            UserDefaults.standard.set("",forKey: "token")
                            profileManager.user = nil
                            userSession.isAuthenticated = false
                            
                        }
                    }
                    
                }
                .navigationTitle("Profile")
                .background(Color.customBackground)
            }
            
        }
        
        else if let librarian = profileManager.user as? Librarian
        {
            NavigationStack {
                List{
                    HStack{
                        VStack{
                            ZStack{
                                Circle()
                                    .fill(Color.gray)
                                    .frame(width: 150, height: 150)
                                
                                Text("\(librarian.name.first!)")
                                    .font(.largeTitle)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                            }
                            Text("\(librarian.name)")
                                .font(.title)
                                .fontWeight(.bold)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    
                    Section{
                        DetailRow(label: "Role", value: librarian.role.rawValue)
                        DetailRow(label: "Phone", value: librarian.phone)
                        DetailRow(label: "Personal Email", value: librarian.personalEmail)
                        DetailRow(label: "Official Email", value: librarian.email)
                    }
                    Section{
                        Button(action: {
                            showingLogoutAlert.toggle()
                        }) {
                            LogoutButton()
                        }
                    }
                    .alert("Are you sure you want to logout?", isPresented: $showingLogoutAlert) {
                        Button("Cancel", role: .cancel) { }
                        Button("Logout", role: .destructive) {
                            UserDefaults.standard.set("",forKey: "token")
                            profileManager.user = nil
                            userSession.isAuthenticated = false
                            
                        }
                    }
                    
                }
                .navigationTitle("Profile")
                .background(Color.customBackground)
            }
        }
        else if let member = profileManager.user as? Member{
            NavigationStack {
                List{
                    HStack{
                        VStack{
                            ZStack{
                                Circle()
                                    .fill(Color.gray)
                                    .frame(width: 150, height: 150)
                                
                                Text("\(member.name.first!)")
                                    .font(.largeTitle)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                            }
                            Text("\(member.name)")
                                .font(.title)
                                .fontWeight(.bold)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    
                    
                    Section{
                        DetailRow(label: "Role", value: member.role.rawValue)
                        DetailRow(label: "Phone", value: member.phone)
                        DetailRow(label: "Personal Email", value: member.email)
                        DetailRow(label: "Selected Library", value: "\(member.selectedLibrary!)")
                    }
                    Section{
                        NavigationLink(destination:IssueHistoryView().environmentObject(getHistoryBooksManager))
                        {
                            Text("Issue History")
                        }
                    }
                    Section{
                        Button(action:{
                            isSwitchLibraryOn = true
                        }){
                            Text("Switch library")
                        }
                    }

                    Section{
                        Button(action: {
                            showingLogoutAlert.toggle()
                        }) {
                            LogoutButton()
                        }
                    }
                    .alert("Are you sure you want to logout?", isPresented: $showingLogoutAlert) {
                        Button("Cancel", role: .cancel) { }
                        Button("Logout", role: .destructive) {
                            UserDefaults.standard.set("",forKey: "token")
                            profileManager.user = nil
                            userSession.isAuthenticated = false
                            
                        }
                    }
                    
                }
                .sheet(isPresented:$isSwitchLibraryOn,content:{
                    MemberSwitchLibraryView(selectedLibrary:getSelectedLibrary())
                        .environmentObject(libraryFetchManager)
                        .environmentObject(bookFetchManager)
                })
                .navigationTitle("Profile")
                .background(Color.customBackground)
            }
        }
    }
}
