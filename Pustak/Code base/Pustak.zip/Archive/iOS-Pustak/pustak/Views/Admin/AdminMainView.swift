//
//  AdminMainView.swift
//  pustak
//
//  Created by Abhay(IOS) on 01/06/24.
//

import SwiftUI

struct AdminMainView: View {
    @EnvironmentObject var adminManager:AdminManager
    @EnvironmentObject var userSession:UserSession
    @EnvironmentObject var profileManager: ProfileManager
    var body: some View {
        TabView{
            if(adminManager.isLoading||profileManager.isLoading)
            {
                ProgressView()
            }
            else
            {
                AdminLibrariesView().tabItem{
                    Label("Libraries",systemImage: "book.fill")
                }
                AdminProfileView()
                    .tabItem{
                    Label("Profile",systemImage: "person.fill")
                }
                    .environmentObject(userSession)
                    .environmentObject(profileManager)
            }
        }
        .onAppear(perform: {
            adminManager.isLoading = true
            profileManager.isLoading = true
            Task{
                do{
                    try await adminManager.fetchLibrary(with:userSession.uId)
                    try await profileManager.fetchProfile(with: userSession.uId)
                }
            }
        })
        .navigationBarBackButtonHidden(true)
    }
        
}

//#Preview {
//    AdminMainView()
//}
