//
//  AdminLibrariansView.swift
//  pustak
//
//  Created by Abhay(IOS) on 01/06/24.
//

import SwiftUI

struct AssignLibrarian: View {
    @Environment(\.dismiss) var dismiss
    @State var name:String = ""
    @State var phone:String = ""
    @State var personalEmail:String = ""
    @State var officialEmail:String = ""
    
    @EnvironmentObject var adminManager:AdminManager
    @EnvironmentObject var userSession:UserSession
    @StateObject var adminAssignLibrarian = AdminAssignLibrarian()
    
    @State private var errorPresented: Bool = false
    var library:Library
    func isDisabled() -> Bool {
        return name.isEmpty || phone.isEmpty || !isValidEmail(personalEmail,isPersonal: true) || !isValidEmail(officialEmail,isPersonal: false)
        }
    var body: some View {
        NavigationStack{
            Form{
                Section("Personal Details")
                {
                    TextField(text: $name, label: {
                        Text("Full Name")
                    })
                    
                    TextField(text:$phone,label:{
                        Text("Phone Number")
                    })
                    .onChange(of: phone){ curPhone in
                        if(curPhone.count <= 10){
                            phone = curPhone.filter({$0.isNumber})
                        }
                        else{
                            phone = String(curPhone.prefix(10))
                        }
                        
                    }
                    TextField(text:$personalEmail,label: {
                        Text("Librarian Personal Email")
                    }).keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                Section("Official Details")
                        {
                    TextField(text:$officialEmail,label:{
                        Text("Official Email")
                    })
                    .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                }
            }
            .toolbar{
                ToolbarItem(placement: .topBarLeading){
                    Button(action:{
                        dismiss()
                    }){Text("Cancel")}
                }
                ToolbarItem(placement: .topBarTrailing)
                {
                    Button(action:{
                        let librarian = Librarian(id: UUID(), role: .librarian, name: name, email: officialEmail, admin: userSession.uId, assignedLibrary: library.id, phone: phone, personalEmail: personalEmail, timestamp: Date(),domain: .infosys)
                        
                        Task{
                            do{
                                try await adminAssignLibrarian.assignLibrarian(with: librarian, of: adminManager)
                                
                                DispatchQueue.main.async{
                                    if(adminAssignLibrarian.isError)
                                    {
                                        errorPresented = true
                                    }
                                    else{
                                        print(adminManager.libraries)
                                    }
                                }
                            }
                            dismiss()
                            
                        }
                        
                    }){
                        Text("Add")
                    }
                    .disabled(isDisabled())
                }
                
            }
        }
    }
}

//#Preview {
//    AssignLibrarian()
//}
