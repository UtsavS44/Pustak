//
//  AdminHomeView.swift
//  pustak
//
//  Created by Abhay(IOS) on 01/06/24.
//

import SwiftUI

struct AdminHomeView: View {
    var body: some View {
        Text("Home Screen")
            .font(.largeTitle)
    }
}

#Preview {
    AdminHomeView()
}
