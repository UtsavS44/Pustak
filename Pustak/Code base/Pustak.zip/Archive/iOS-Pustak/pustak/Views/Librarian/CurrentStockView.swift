//
//  CurrentStockView.swift
//  pustak
//
//  Created by Abhay(IOS) on 07/06/24.
//

import SwiftUI

struct CurrentStockView: View {
    @EnvironmentObject var getBooksManager: LibrarianFetchBookManager
    @State var searchableText = ""
    var filterbooks: [Books]{
        if searchableText.isEmpty{
            return getBooksManager.books
        }
        else{
            return  getBooksManager.books.filter{$0.title.localizedCaseInsensitiveContains(searchableText)}
        }
    }
    var libraryId:String
    var body: some View {
        List{
            ForEach(filterbooks){ book in
                LibrarianBookCard(book:book)
            }
        }.onAppear(perform: {
            Task{
                do{
                    try await getBooksManager.fetchBooks(with:UUID(uuidString: libraryId)!)
                }
            }
        })
        .navigationTitle("Current Stock")
        .searchable(text: $searchableText, prompt: "Search books")
    }
}

//#Preview {
//    CurrentStockView()
//}
