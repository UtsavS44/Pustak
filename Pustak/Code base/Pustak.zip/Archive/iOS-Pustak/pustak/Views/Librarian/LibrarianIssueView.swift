//
//  LibrarianIssueView.swift
//  pustak
//
//  Created by Abhay(IOS) on 14/06/24.
//

import SwiftUI

struct LibrarianIssueView: View {
    @EnvironmentObject var getIssuedBooks:LibrarianIssueRequestManager
    var issuedBooks:[LibrarianIssueBook]{
        getIssuedBooks.books.filter{$0.issueStatus == .approved}
    }
    var body: some View {
            NavigationStack{
                ScrollView{
                    VStack{
                        ForEach(issuedBooks){book in
                            NavigationLink(destination:LibrarianIssuedBookDetailView(book:book)){
                                LibrarianIssuedBookCard(book: book)
                            }
                            
                        }
                    }
                }
            .navigationTitle("Issued")
            }
    }
}

//#Preview {
//    LibrarianIssueView()
//}
