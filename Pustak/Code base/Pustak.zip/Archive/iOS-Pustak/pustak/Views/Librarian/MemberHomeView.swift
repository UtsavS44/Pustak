//
//  MemberHomeView.swift
//  pustak
//
//  Created by Abhay(IOS) on 03/06/24.
//

import SwiftUI

struct MemberHomeView: View {
    @EnvironmentObject var bookManager:LibrarianFetchBookManager
    @EnvironmentObject var getIssueBooks:GetIssueBookManager
    
    var pendingRequests:[MemberIssueBook]{
        getIssueBooks.issuedBooks.filter({$0.issueStatus == .pending})
    }
    var body: some View {
        NavigationStack{
            ScrollView{
                VStack(alignment:.leading,spacing: 20){
                    Text("Pending Requests")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding(.leading, 20).padding(.top, 20)
                    ScrollView(.horizontal,showsIndicators: false){
                        HStack(spacing:12){
                            if(!pendingRequests.isEmpty){
                                ForEach(pendingRequests) { book in
                                    if book.issueStatus == .pending {
                                        PendingRequestCard(book: book)
                                            .padding()
                                            .frame(width: 300, height: 120)
                                            .background(
                                                LinearGradient(gradient: Gradient(colors: [Color(UIColor.secondarySystemBackground), Color(UIColor.secondarySystemBackground)]),
                                                               startPoint: .topLeading, endPoint: .bottomTrailing)
                                            )
                                            .cornerRadius(10)
                                    }
                                }
                            }
                            else{
                                Text("No Pending Requests")
                                            .font(.headline)
                                            .fontWeight(.bold)
                                            .foregroundColor(.white)
                                            .frame(width: 380, height: 120)
                                            .background(
                                                RoundedRectangle(cornerRadius: 15)
                                                    .fill(buttonBrownGradient)
                                            )
                                            .padding(.leading, 5)
                            }

                        }
                    }
                    
                    Text("Browse Categries")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding(.leading, 20).padding(.top, 20)
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                        
                        NavigationLink(destination: MemberAllBooksView()) {
                            MemberAllBooksCard()
                        }
                        .environmentObject(bookManager)
                        
                        ForEach(Genre.allCases, id: \.self) { category in
                            NavigationLink(destination: MemberCategoryBookView(category: category)) {
                                MemberCategoryCard(category: category)
                            }
                            .environmentObject(bookManager)
                        }
                    }
                    .navigationTitle("Home")
                    .padding(.horizontal, 10)
                    .padding(.top, 10)
                }
            }
        }
        //        .onAppear(perform: {
        //            Task{
        //                do{
        //                }catch{
        //
        //                }
        //            }
        //        })
    }
}
//
//#Preview {
//    MemberHomeView()
//}
