//
//  LibrarianIssuedBookDetailView.swift
//  pustak
//
//  Created by Abhay(IOS) on 14/06/24.
//

import SwiftUI

struct LibrarianIssuedBookDetailView: View {
    var book:LibrarianIssueBook
    var body: some View {
        NavigationStack{
            List{
                Section(header: Text("Issuer Details")) {
                    HStack {
                        Text("Name")
                        Spacer()
                        Text(book.user.name)
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Email")
                        Spacer()
                        Text(book.user.email)
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Phone")
                        Spacer()
                        Text(book.user.phone)
                            .foregroundColor(.secondary)
                    }
                }
                Section(header: Text("Bookdetails")) {
                    HStack {
                        Text("Title")
                        Spacer()
                        Text(book.book.title)
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Authon")
                        Spacer()
                        Text(book.book.author)
                            .foregroundColor(.secondary)
                    }
                    HStack {
                        Text("ISBN")
                        Spacer()
                        Text(book.book.ISBN)
                            .foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle(book.book.title)
        }
    }
}

//#Preview {
//    LibrarianIssuedBookDetailView()
//}
