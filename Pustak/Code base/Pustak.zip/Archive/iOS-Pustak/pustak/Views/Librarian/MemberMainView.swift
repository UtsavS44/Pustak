//
//  MemberMainView.swift
//  pustak
//
//  Created by Abhay(IOS) on 03/06/24.
//

import SwiftUI

struct MemberMainView: View {
    @EnvironmentObject var userSession:UserSession
    @EnvironmentObject var bookManager:LibrarianFetchBookManager
    @EnvironmentObject var profileManager:ProfileManager
    @EnvironmentObject var bookFetchManager: LibrarianFetchBookManager
    @StateObject var domainLibraryManager = FetchLibrariesWithDomain()
    @StateObject var fetchWishlistManager = MemberGetWishlist()
    @StateObject var wishlistActionManager = MemberWishlistManager()
    @StateObject var getIssueBooks = GetIssueBookManager()
    var body: some View {
        if let user = profileManager.user as? Member{
            if let selectedLibrary = user.selectedLibrary{
                TabView{
                    MemberHomeView()
                        .tabItem{
                            Label("Home",systemImage: "house.fill")
                            
                        }
                    MemberFavouritesView()
                        .tabItem{
                            Label("Favourites",systemImage: "heart.fill")
                        }
                    MemberBooksView()
                        .tabItem{
                            Label("My Books",systemImage: "book.fill")
                        }
                    AdminProfileView()
                        .tabItem {
                            Label("Profile",systemImage: "person.crop.circle")
                        }
                        .environmentObject(userSession)
                        .environmentObject(profileManager)
                }.environmentObject(bookFetchManager)
                    .environmentObject(fetchWishlistManager)
                    .environmentObject(wishlistActionManager)
                    .environmentObject(getIssueBooks)
                    .onAppear(perform: {
                        Task{
                            do{
                                try await bookFetchManager.fetchBooks(with: selectedLibrary)
                                try await fetchWishlistManager.getWishlist(with: userSession.uId,library: getSelectedLibrary())
                                try await getIssueBooks.getIssuedBooks(userSession.uId, libraryId: getSelectedLibrary())
                            }
                        }
                    })
            }
            else{
                MemberLibrariesView()
                    .environmentObject(profileManager)
                    .environmentObject(domainLibraryManager)
            }
            
        }
        else{
            ProgressView()
                .onAppear(perform: {
                    Task{
                        do{
                            try await profileManager.fetchProfile(with: userSession.uId)
                            guard let user  = profileManager.user as? Member else {return}
                            guard let selectedLibrary = user.selectedLibrary else {return}
                            UserDefaults.standard.set(selectedLibrary.uuidString,forKey: "selectedLibrary")
                        }catch{}
                    }
                })
        }
    }
}
//
//#Preview {
//    MemberMainView()
//}
