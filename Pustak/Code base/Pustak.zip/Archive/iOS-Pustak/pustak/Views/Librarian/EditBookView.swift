//
//  EditBookView.swift
//  pustak
//
//  Created by Abhay(IOS) on 11/06/24.
//

import SwiftUI

struct EditBookDetailsView: View {
    var book:Books
    @EnvironmentObject var userSession:UserSession
    @EnvironmentObject var librarymanager:LibrarianFetchBookManager
    @Environment (\.dismiss) var dismiss
    @StateObject var libraryEditBookManager = LibrarianUpdateBookManager()
    @State private var title: String = ""
    @State private var ISBN: String = ""
    @State private var author: String = ""
    @State private var publisher:String = ""
    @State private var nosPages:String = ""
    @State private var qty:String = ""
    @State private var bookDescription: String = ""
    @State private var yearPublished: String = ""
    var body: some View {
        NavigationStack{
            Form{
                Section(header: Text("Title")) {
                    
                    InputField(text: $title, placeholder: "Library name", cornerRadius: 10)
                }
                Section(header:Text("ISBN")){
                    InputField(text: $ISBN, placeholder: "Library Contact", cornerRadius: 10)
                }
                Section(header:Text("Author")){
                    InputField(text: $author, placeholder: "Library Email", cornerRadius: 10)
                }
                Section(header:Text("Publisher")){
                    InputField(text: $publisher, placeholder: "Library Address", cornerRadius: 10)
                }
                Section(header:Text("Year Published")){
                    InputField(text: $yearPublished, placeholder: "Library Address", cornerRadius: 10)
                }
                Section(header:Text("Pages")){
                    InputField(text: $nosPages, placeholder: "Library Address", cornerRadius: 10)
                }
                Section(header:Text("Quantity")){
                    InputField(text: $qty, placeholder: "Library Address", cornerRadius: 10)
                }
                Section(header:Text("Description")){
                    InputField(text: $bookDescription, placeholder: "Library Address", cornerRadius: 10)
                }
                            }
            .navigationTitle("Edit Library")
            .toolbar{
                ToolbarItem(placement:.topBarLeading){
                    Button(action:{
                        dismiss()
                    }){
                        Text("Cancel")
                    }
                }
                ToolbarItem(placement:.topBarTrailing){
                    Button(action:{
                        let book = Books(id: book.id, ISBN: ISBN, title: title, yearPublished: yearPublished, author: author, publisher: publisher, genre: book.genre, nosPages: nosPages, libraryId: book.libraryId, qty: Int(qty)!,description: book.description ,timestamp: book.timestamp)
                        Task{
                            do{
                                try await libraryEditBookManager.updateBook(with: book, of: librarymanager)
                            }catch{}
                        }
                        dismiss()
                    }){
                        Text("Save")
                    }
                }
            }
            .onAppear(perform: {
            title = book.title
                ISBN = book.ISBN
                author = book.author
                publisher = book.publisher
                nosPages = book.nosPages
                qty = book.nosPages
                bookDescription = book.description
                 yearPublished = bookDescription
            })
        }
        
        
    }
}

//#Preview {
//    EditBookView()
//}
