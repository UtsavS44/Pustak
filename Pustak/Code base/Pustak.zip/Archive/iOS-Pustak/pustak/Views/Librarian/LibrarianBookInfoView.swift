//
//  LibrarianBookInfoView.swift
//  pustak
//
//  Created by Abhay(IOS) on 10/06/24.
//

import SwiftUI

struct LibrarianBookInfoView: View {
    var book:Books
    @EnvironmentObject var libraryManager:LibrarianFetchBookManager
    @StateObject var bookDeleteManager = LibrarianDeleteBookManager()
    @State private var isEditShown = false
    @State var isDeleteShown = false
    @Environment(\.dismiss) var dismiss
    var body: some View
    {
        List{
            Section(header:Text("Book Information"))
            {
                HStack{
                    Spacer()
                    BookCoverView(bookName: book.title, authorName: book.author)
                        .frame(width:150,height: 200)
                    Spacer()
                    
                }
                DetailRow(label: "ISBN", value: book.ISBN)
                DetailRow(label: "Title", value: book.title)
                DetailRow(label: "Author", value: book.author)
                DetailRow(label: "Publisher", value: book.publisher)
                DetailRow(label: "Genre", value: book.genre.rawValue)
                DetailRow(label: "Year Published", value: book.yearPublished)
                DetailRow(label: "Number of Pages", value: book.nosPages)
                DetailRow(label: "Quantity", value: String(book.qty))
                DetailRow(label: "Description", value: book.description)
                Button(action:{
                    isEditShown = true
                }){
                    Text("Edit book details")
                }
            }
            Section{
                Button(action:{
                    isDeleteShown = true
                }){
                    Text("Delete book")
                }
            }
        }
        .navigationTitle(book.title)
        .alert("Are you user you want to delete this book?",isPresented: $isDeleteShown)
        {
            Button("Cancel",role:.cancel){}
            Button("Confirm",role:.destructive){
                Task{
                    do{
                        try await bookDeleteManager.deleteBook(with: book, of: libraryManager)
                    }
                    dismiss()
                }
            }
            
        }
        .sheet(isPresented:$isEditShown)
        {
            EditBookDetailsView(book: book)
        }
    }
}

//#Preview {
//    LibrarianBookInfoView(book: Books(id: UUID(), ISBN: "akbf", title: "lsakn", yearPublished: "24343", author: "kbjasd", publisher: "afjnk", genre: Genre.comedy, nosPages: "2143", libraryId: UUID(), qty: "5", timestamp: Date(),description: "ahfabjfkas sa,nfjlansfkl fjksansajkfb aksjfankjfslaf kahsfjkafjskajlkf kashfjkafs"))
//}
