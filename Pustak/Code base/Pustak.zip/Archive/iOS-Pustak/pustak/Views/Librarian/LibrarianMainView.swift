//
//  LibrarianMainView.swift
//  pustak
//
//  Created by Abhay(IOS) on 01/06/24.
//

import SwiftUI

struct LibrarianMainView: View {
    @EnvironmentObject var libraryManager:LibrarianFetchBookManager
    @EnvironmentObject var userSession:UserSession
    @EnvironmentObject var profileManager: ProfileManager
    @StateObject var librarianIssueBookManager = LibrarianIssueRequestManager()
    var body: some View {
        TabView{
            LibrarianHomeView().tabItem {
                Label("Library", systemImage: "house.fill")
            }
            LibrarianRequestsView().tabItem {
                Label("Requests", systemImage: "tray.and.arrow.down.fill")
            }
            LibrarianIssueView().tabItem {
                Label("Issued",systemImage: "books.vertical.fill")
            }
            AdminProfileView().tabItem {
                Label("Profile", systemImage: "person.crop.circle")
            }
            .environmentObject(profileManager)
            .environmentObject(userSession)
        }
        .environmentObject(librarianIssueBookManager)
        .onAppear(perform: {
            Task{
                do{
                   try await profileManager.fetchProfile(with: userSession.uId)
                    guard let user = profileManager.user as? Librarian else {return}
                    try await librarianIssueBookManager.librarianIssueBookRequest(libraryID:user.assignedLibrary)
                    
                }
            }
        })
        .navigationBarBackButtonHidden(true)
    }
}

//#Preview {
//    LibrarianMainView()
//}
