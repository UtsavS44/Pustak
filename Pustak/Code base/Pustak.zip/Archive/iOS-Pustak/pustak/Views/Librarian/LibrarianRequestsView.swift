//
//  LibrarianIssueView.swift
//  pustak
//
//  Created by Abhay(IOS) on 11/06/24.
//

import SwiftUI

struct LibrarianRequestsView: View {
    @EnvironmentObject var getActiveRequests:LibrarianIssueRequestManager
    var pendingRequests:[LibrarianIssueBook]{
        getActiveRequests.books.filter{$0.issueStatus == .pending}
    }
    var body: some View {
        NavigationStack{
                ScrollView{
                    if(!pendingRequests.isEmpty){
                    VStack{
                        ForEach(pendingRequests){request in
                            LibrarianBookRequestCard(book: request)
                        }
                    }
                    }else{
                        Text("No requests available")
                            .padding(.top,20)
                            .font(.title2)
                            .foregroundStyle(buttonBrownGradient)
                    }
            }
            .navigationTitle("Requests")
        }
    }
}

//#Preview {
//    LibrarianIssueView()
//}
