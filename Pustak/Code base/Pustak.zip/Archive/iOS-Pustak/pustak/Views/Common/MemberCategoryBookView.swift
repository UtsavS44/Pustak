//
//  MemberCategoryBookView.swift
//  pustak
//
//  Created by Abhay(IOS) on 12/06/24.
//

import SwiftUI

struct MemberCategoryBookView: View {
    @EnvironmentObject var bookManager:LibrarianFetchBookManager
    @State var searchableText = ""
    var filterbooks: [Books]{
        if searchableText.isEmpty{
            return bookManager.books
        }
        else{
            return  bookManager.books.filter{$0.title.localizedCaseInsensitiveContains(searchableText)}
        }
    }
    var category:Genre
    var body: some View {
        List{
            ForEach(filterbooks){ book in
                if(book.genre == category)
                {
                    MemberBookCard(book: book)
                        .environmentObject(bookManager)
                }
            }
        }
        .navigationTitle("\(category.rawValue)")
        .searchable(text: $searchableText, prompt: "Search books")
    }
}

//#Preview {
//    MemberCategoryBookView()
//}
