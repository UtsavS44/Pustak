//
//  LaunchScreen.swift
//  pustak
//
//  Created by Abhay(IOS) on 14/06/24.
//

import SwiftUI

struct LaunchScreenView: View {
    @State private var isActive = false
    @State private var scale: CGFloat = 1
    @State private var opacity: Double = 0

    var body: some View {
        if isActive{
            ContentView()
        }
        else{
            VStack{
                VStack {
                    Image("launchIcon2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 150, height: 150)
                        .scaleEffect(scale)
                        .opacity(opacity)
                        .onAppear {
                            withAnimation(.easeInOut(duration: 2)) {
                                scale = 1
                                opacity = 1.0
                            }
                        }
                }
                .onAppear{
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.0){
                        withAnimation{
                            self.isActive = true
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(red: 233 / 255, green: 220 / 255, blue: 200 / 255))
            .ignoresSafeArea()
        }
    }
}
