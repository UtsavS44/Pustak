//
//  pustakApp.swift
//  pustak
//
//  Created by Abhay(IOS) on 28/05/24.
//

import SwiftUI

@main
struct pustakApp: App {
    var body: some Scene {
        WindowGroup {
//            AdminMainView()
            LaunchScreenView()
        }
        
    }
}
