//
//  BookCover.swift
//  pustak
//
//  Created by Abhay(IOS) on 07/06/24.
//

import Foundation
import SwiftUI

enum FontStyleType{
    case title
    case title2
    case title3
    case caption
    case body
    
    var font: Font{
        switch self{
        case .title:
            return .title
        case .body:
            return .body
        case .title2:
            return .title2
        case .title3:
            return .title3
        case .caption:
            return .caption
        }
        
    }
}
struct VerticalDivider: View{
    var x: CGFloat = 1
//    var y: CGFloat = 1
    var body: some View{
        Rectangle().fill(Color.customBrown.opacity(0.8))
            .frame(width: x)
    }
    
}
//
//struct BookCover: View{
//    var bookName:String
//    var authName:String
//    var width: CGFloat = 50
//    var height: CGFloat = 60
//    var BnamefontType: FontStyleType = .title
//    var BauthorfontType: FontStyleType = .caption
//    
//    
//    var body: some View{
////        var bookCoverColor:[Color] = [Color.cyan, Color.red, Color.orange]
//        var lineargradients: [LinearGradient] = [
//            LinearGradient(colors: [.customText, .customToggleText], startPoint: .topLeading, endPoint: .bottomTrailing)
//        ]
//       
//        
//        let randomColor = lineargradients.randomElement()
//        HStack(spacing: 10){
//            VStack(alignment: .leading){
//                VerticalDivider().frame(height: height - 5 )
//                
//            }
//            
//            
//            VStack(alignment: .leading){
//                Text("\(bookName)")
//                    .font(.system(size:10))
//                    .fontWeight(.bold)
//                    .multilineTextAlignment(.leading)
//                    .foregroundColor(.white)
//                    .padding(.top).padding(.trailing,2).padding(.leading, 5)
//                Spacer()
//                Text("\(authName)")
//                    .font(.system(size: 8))
//                    .fontWeight(.bold)
//                    .foregroundColor(.white)
//                    .padding(.top)
//                    .padding(.leading, 5)
////                Spacer()
//                
//            }
//        }.frame(width: width, height: height).background(randomColor)
//    }
//}
//
//#Preview{
//    BookCover(bookName: "A day in life of Anushka", authName: "Amol", width: 150, height: 200)
//}
//import SwiftUI
//
//struct BookCoverView: View {
//    let bookName: String
//    let authorName: String
//    var height: CGFloat
//    var width: CGFloat
//    
//
//    var body: some View {
//        ZStack {
//            // Background for the book cover
//            RoundedRectangle(cornerRadius: 10)
//                .fill(LinearGradient(
//                    gradient: Gradient(colors: [Color.customToggleText, Color.customText]),
//                    startPoint: .topLeading,
//                    endPoint: .bottomTrailing))
//                .shadow(radius: 10)
//            
//            // Text on the book cover
//            VStack {
//                Spacer()
//                Text(bookName)
//                    .font(.title2)
//                    .fontWeight(.bold)
//                    .foregroundColor(.white)
//                    .multilineTextAlignment(.center)
//                    .padding([.leading, .trailing], 10)
//                Text(authorName)
//                    .font(.headline)
//                    .foregroundColor(.white)
//                    .padding(.top, 5)
//                    .padding([.leading, .trailing], 10)
//                Spacer()
//            }
//            .padding()
//        }
//        .frame(width: width, height: height)
//        .padding()
//    }
//}

import SwiftUI

struct BookCoverView: View {
    let bookName: String
    let authorName: String
    var body: some View {
        ZStack {
            // Background for the book cover
            RoundedRectangle(cornerRadius: 10)
                .fill(buttonBrownGradient)
                .shadow(radius: 10)
            
            // Text on the book cover
            VStack {
                Spacer()
                Text(bookName)
                    .font(.system(.title, design: .default))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.01) // Allows text to scale down
                    .lineLimit(2)
                    .padding([.leading, .trailing], 10)
                Text(authorName)
                    .font(.system(.headline, design: .default))
                    .foregroundColor(.white)
                    .minimumScaleFactor(0.01) // Allows text to scale down
                    .lineLimit(1)
                    .padding(.top, 5)
                    .padding([.leading, .trailing], 10)
                Spacer()
            }
            .padding()
        }
        .aspectRatio(2/3, contentMode: .fit)
    }
}

//struct BookCoverView_Previews: PreviewProvider {
//    static var previews: some View {
//        VStack {
//            BookCoverView(bookName: "The Great Gatsby", authorName: "F. Scott Fitzgerald")
//                .frame(width: 200, height: 300)
//            BookCoverView(bookName: "To Kill a Mockingbird", authorName: "Harper Lee")
//                .frame(width: 150, height: 225)
//        }
//    }
//}


//struct BookCoverView_Previews: PreviewProvider {
//    static var previews: some View {
//        BookCoverView(bookName: "Example Book Title", authorName: "John Doe", height:100, 200)
//    }
//}
