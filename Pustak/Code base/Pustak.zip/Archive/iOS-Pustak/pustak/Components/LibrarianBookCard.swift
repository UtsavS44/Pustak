//
//  LibrarianBookCard.swift
//  pustak
//
//  Created by Abhay(IOS) on 07/06/24.
//

import SwiftUI

struct LibrarianBookCard: View {
    var book:Books
    var body: some View {
        NavigationLink(destination: LibrarianBookInfoView(book:book)) {
                    HStack(spacing: 16) {
                        BookCoverView(bookName: book.title, authorName: book.author)
                            .frame(width: 50,height: 100)
                            .padding(.vertical,0)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("\(book.title)")
                                .font(.title2)
                                .foregroundColor(.primary)
                            Text("\(book.author)")
                                .font(.title3)
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                }
    }
}

//#Preview {
//    LibrarianBookCard()
//}
