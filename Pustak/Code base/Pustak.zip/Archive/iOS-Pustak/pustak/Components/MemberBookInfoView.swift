//
//  MemberBookInfoCard.swift
//  pustak
//
//  Created by Abhay(IOS) on 12/06/24.
//

import SwiftUI

struct MemberBookInfoView: View {
    var book:Books
    @EnvironmentObject var bookManager:LibrarianFetchBookManager
    @EnvironmentObject var getWishlist:MemberGetWishlist
    @EnvironmentObject var userSession:UserSession
    @EnvironmentObject var wishlistActionManager:MemberWishlistManager
//    var suggestedBooks: [Books] {
//            bookManager.books.filter { $0.genre == book.genre }
//        }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading) {
                        HStack(alignment: .top, spacing: 16) {
                            BookCoverView(bookName: book.title, authorName: book.author)
                            .padding(.leading, 20)
                            .frame(width: 150, height: 250)
                            
                            BookTopContent(book:book)
                                .environmentObject(getWishlist)
                                .environmentObject(userSession)
                                .environmentObject(wishlistActionManager)
                            
                        }
                    Divider().background(Color.primary).padding(.horizontal, 20)
                    
                    VStack(alignment: .leading) {
                        HStack {
                            Text("Summary")
                                .font(.title2)
                                .fontWeight(.semibold)
                            Spacer()
                        }
                        .padding(.bottom, 4)
                        .padding(.horizontal, 20)
                        
                        Text(book.description)
                        .font(.subheadline)
                        .foregroundColor(.primary)
                        .padding()
                        .frame(maxWidth: .infinity,alignment: .leading)
                        .background(
                            RoundedRectangle(cornerRadius: 9)
                                .fill(Color(UIColor.secondarySystemBackground))
                                .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
                        )
                        .padding(.horizontal, 20)
                        .padding(.bottom, 20)
                        
                        Spacer()
                    }
                    
//                    VStack(alignment: .leading, spacing: 8) {
//                        Text("More like this")
//                            .font(.title2)
//                            .fontWeight(.semibold)
//                            .padding(.horizontal, 20)
//                        
//                        ScrollView(.horizontal, showsIndicators: false) {
//                            HStack(spacing: 16) {
//                                ForEach(suggestedBooks,id: \.ISBN) { bookSuggest in
//                                    MemberBookInfoView(book: bookSuggest)
//                                    .padding(.leading, 5)
//                                }
//                            }
//                            .padding(.horizontal, 20)
//                        }
//                    }
//                    .padding(.bottom)
                }
            }
            .navigationTitle(book.title)
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

