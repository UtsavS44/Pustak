//
//  DetailRow.swift
//  pustak
//
//  Created by Abhay(IOS) on 11/06/24.
//

import SwiftUI

struct DetailRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack {
            Text(label)
                .font(.headline)
            Spacer()
            Text(value)
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 5)
    }
}

//#Preview {
//    DetailRow()
//}
