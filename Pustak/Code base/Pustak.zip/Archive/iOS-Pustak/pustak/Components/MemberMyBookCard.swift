//
//  MemberMyBookCard.swift
//  pustak
//
//  Created by Abhay(IOS) on 14/06/24.
//

import SwiftUI

struct MemberMyBookCard: View {
    var book:MemberIssueBook
    var body: some View {
        HStack(spacing: 16) {
            BookCoverView(bookName: book.book.title, authorName: book.book.author)
                .frame(width: 50,height: 100)
                .padding(.vertical,0)
            
            VStack(alignment: .leading, spacing: 4) {
                Text("\(book.book.title)")
                    .font(.title2)
                    .foregroundColor(.primary)
                Text("\(book.book.author)")
                    .font(.title3)
                    .foregroundColor(.secondary)
            }
            Spacer()
        }
        .tint(.customBrown)
    }
}

//#Preview {
//    MemberMyBookCard()
//}
