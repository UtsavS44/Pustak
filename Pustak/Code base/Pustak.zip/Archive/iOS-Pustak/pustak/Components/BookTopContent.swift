//
//  BookTopContent.swift
//  pustak
//
//  Created by Abhay(IOS) on 12/06/24.
//

import SwiftUI

struct BookTopContent: View {
    var book:Books
    @EnvironmentObject var wishlistActionmanager:MemberWishlistManager
    @EnvironmentObject var profileManager:ProfileManager
    @EnvironmentObject var userSession:UserSession
    @EnvironmentObject var getWishlistManager:MemberGetWishlist
    @EnvironmentObject var bookFetchManager:LibrarianFetchBookManager
    @EnvironmentObject var getIssueBooks:GetIssueBookManager
    @StateObject var memberBookRequestManager = MemberIssueRequestManager()
    
    //    var book: BookStatus
    @State private  var showingAlert1 = false
    @State private  var showingAlert2 = false
    
    @State private var isReserved = false
    @State private var buttonColor1 = Color(#colorLiteral(red: 0.4862745098, green: 0.2470588235, blue: 0.2431372549, alpha: 1))
    @State private var buttonColor2 = Color(#colorLiteral(red: 0.4862745098, green: 0.2470588235, blue: 0.2431372549, alpha: 1))
    
    @State private var content1 = "Issue"
    @State private var content2 = "Add To Favourites"
    
    func isBorrowed() -> Bool{
        return getIssueBooks.isRequested(id: book.id, issue: getIssueBooks.issuedBooks)
    }
    
    var body: some View {
        VStack(alignment: .leading) {
            
            Text(book.title)
                .font(.title)
                .foregroundColor(.primary)
                .multilineTextAlignment(.leading).padding(.leading, 20).padding(.top, 20)
                .lineLimit(nil)
                .fixedSize(horizontal: false, vertical: true)
            
            Text(book.author)
                .font(.subheadline)
                .foregroundColor(.gray)
                .padding(.leading, 20).padding(.bottom, 2)
            Spacer()
            VStack{
                Button(action: {
                    Task{
                        do{
                            try await memberBookRequestManager.issueRequest(with:Issues(id: UUID(), bookId: book.id, startDate: Date(), endDate: Date().addingTimeInterval(720*60), userId: userSession.uId, issueStatus: .pending, libraryId: getSelectedLibrary(), returned: false, timestamp: Date()),book: book,of: getIssueBooks)
                        }
                    }
                }) {
                    MemberCustomButton(content: content1,isActive: true)
                }
                .disabled(isBorrowed())
                .opacity(isBorrowed() ? 0.5 : 1)
                
                Button(action:{
                    if(!bookFetchManager.isFav(id: book.id, wishlist: getWishlistManager.wishlist))
                    {
                        Task{
                            let item = AddToWishlist(book: book.id, userId: userSession.uId,libraryId: getSelectedLibrary())
                            wishlistActionmanager.isLoading = true
                            print(item)
                            do{
                                try await wishlistActionmanager.addToWishlist(with: book,userId:userSession.uId,libraryId:getSelectedLibrary(), of: getWishlistManager)
                                wishlistActionmanager.isLoading = false
                            }catch{
                                
                            }
                        }

                    }
                    else{
                        Task{
                            let _ = AddToWishlist(book: book.id, userId: userSession.uId,libraryId: getSelectedLibrary())
                            wishlistActionmanager.isLoading = true
                            do{
                                try await wishlistActionmanager.removeFromWishlist(with: book,userId:userSession.uId,libraryId:getSelectedLibrary(), of: getWishlistManager)
                                wishlistActionmanager.isLoading = false
                            }
                        }
                    }
                }){
                    if(!bookFetchManager.isFav(id: book.id, wishlist: getWishlistManager.wishlist)){
                        MemberCustomButton(content: content2,isActive: true)
                    }
                    else{
                        MemberCustomButton(content: "Remove",isActive: false)
                    }
                }
            }.padding(.leading, 20).padding(.bottom, 20)
        }
        .frame(width: 200)
    }
}
//
//#Preview {
//    BookTopContent()
//}
