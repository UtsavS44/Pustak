//
//  MemberBooksView.swift
//  pustak
//
//  Created by Abhay(IOS) on 12/06/24.
//

import SwiftUI

struct MemberBooksView: View {
    @EnvironmentObject var getIssuedBooks:GetIssueBookManager
    var body: some View {
        NavigationStack{
                List{
                    ForEach(getIssuedBooks.issuedBooks){book in
                        if(book.issueStatus == .approved){
                           MemberMyBookCard(book: book)
                        }
                    }
                }
            .navigationTitle("My Books")
        }
    }
}
