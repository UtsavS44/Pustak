//
//  LibrarianBookRequestCard.swift
//  pustak
//
//  Created by Abhay(IOS) on 13/06/24.
//

import SwiftUI

//struct LibrarianBookRequestCard: View {
//    @State private var showAlert = false
//    @State private var alertMessage = ""
//
//    var body: some View {
//        VStack {
//            VStack(alignment: .leading, spacing: 10) {
//                Text("Book Request")
//                    .font(.headline)
//                    .padding(.bottom, 5)
//
//                HStack {
//                    Text("Issuer:")
//                        .font(.subheadline)
//                    Spacer()
//                    Text("Piyush Saini")
//                        .foregroundColor(.secondary)
//                }
//                HStack {
//                    Text("Book name:")
//                        .font(.subheadline)
//                    Spacer()
//                    Text("Harry Potter")
//                        .foregroundColor(.secondary)
//                }
//                HStack(spacing: 20) {
//                    Button(action: {
//                        alertMessage = "Request accepted"
//                        showAlert = true
//                    }) {
//                        Text("Accept")
//                            .frame(maxWidth: .infinity, minHeight: 44)
//                            .background(Color.green)
//                            .foregroundColor(.white)
//                            .cornerRadius(8)
//                    }
//                    Button(action: {
//                        alertMessage = "Request rejected"
//                        showAlert = true
//                    }) {
//                        Text("Reject")
//                            .frame(maxWidth: .infinity, minHeight: 44)
//                            .background(Color.red)
//                            .foregroundColor(.white)
//                            .cornerRadius(8)
//                    }
//                }
//            }
//            .padding()
//            .background(RoundedRectangle(cornerRadius: 10).fill(Color(.systemBackground)))
//            .shadow(radius: 5)
//            .padding()
//        }
//        .background(Color(.systemGroupedBackground))
//        .alert(isPresented: $showAlert) {
//            Alert(title: Text(alertMessage))
//        }
//    }
//}

//struct LibrarianBookRequestCard: View {
//    @State private var showAlert = false
//    @State private var alertMessage = ""
//
//    var body: some View {
//        VStack {
//            VStack(alignment: .leading, spacing: 12) {
//                Text("Book Request")
//                    .font(.headline)
//                    .padding(.bottom, 5)
//
//                HStack {
//                    Text("Issuer:")
//                        .font(.subheadline)
//                        .fontWeight(.medium)
//                    Spacer()
//                    Text("Piyush Saini")
//                        .foregroundColor(.secondary)
//                }
//                HStack {
//                    Text("Book Name:")
//                        .font(.subheadline)
//                        .fontWeight(.medium)
//                    Spacer()
//                    Text("Harry Potter")
//                        .foregroundColor(.secondary)
//                }
//
//                Divider()
//
//                HStack(spacing: 20) {
//                    Button(action: {
//                        alertMessage = "Request accepted"
//                        showAlert = true
//                    }) {
//                        Text("Accept")
//                            .frame(minWidth: 140, minHeight: 44)
//                            .background(Color.green)
//                            .foregroundColor(.white)
//                            .cornerRadius(8)
//                            .font(.headline)
//                    }
//                    Button(action: {
//                        alertMessage = "Request rejected"
//                        showAlert = true
//                    }) {
//                        Text("Reject")
//                            .frame(minWidth: 140, minHeight: 44)
//                            .background(Color.red)
//                            .foregroundColor(.white)
//                            .cornerRadius(8)
//                            .font(.headline)
//                    }
//                }
//                .padding(.top, 10)
//            }
//            .padding()
//            .background(
//                RoundedRectangle(cornerRadius: 10)
//                    .fill(Color(UIColor.systemBackground))
//                    .shadow(color: Color(UIColor.systemGray4).opacity(0.5), radius: 5, x: 0, y: 2)
//            )
//            .padding(.horizontal)
//        }
//        .background(Color(UIColor.systemGroupedBackground).edgesIgnoringSafeArea(.all))
//        .alert(isPresented: $showAlert) {
//            Alert(title: Text(alertMessage))
//        }
//    }
//}


//struct LibrarianBookRequestCard: View {
//    @State private var showAlert = false
//    @State private var alertMessage = ""
//
//    var body: some View {
//        VStack {
//            VStack(alignment: .leading, spacing: 12) {
//                Text("Book Request")
//                    .font(.headline)
//                    .padding(.bottom, 5)
//
//                HStack {
//                    Text("Issuer:")
//                        .font(.subheadline)
//                        .fontWeight(.medium)
//                    Spacer()
//                    Text("Piyush Saini")
//                        .foregroundColor(.secondary)
//                }
//                HStack {
//                    Text("Book Name:")
//                        .font(.subheadline)
//                        .fontWeight(.medium)
//                    Spacer()
//                    Text("Harry Potter")
//                        .foregroundColor(.secondary)
//                }
//
//                Divider()
//
//                HStack(spacing: 20) {
//                    Button(action: {
//                        alertMessage = "Request accepted"
//                        showAlert = true
//                    }) {
//                        Text("Accept")
//                            .frame(minWidth: 140, minHeight: 44)
//                            .background(
//                                buttonBrownGradient
//                            )
//                            .foregroundColor(.white)
//                            .cornerRadius(8)
//                            .font(.headline)
//                    }
//                    Button(action: {
//                        alertMessage = "Request rejected"
//                        showAlert = true
//                    }) {
//                        Text("Reject")
//                            .frame(minWidth: 140, minHeight: 44)
//                            .background(
//                                buttonBrownGradient
//                            )
//                            .foregroundColor(.white)
//                            .cornerRadius(8)
//                            .font(.headline)
//                    }
//                }
//                .padding(.top, 10)
//                .frame(maxWidth: .infinity, alignment: .center) // Center the buttons
//            }
//            .padding()
//            .background(
//                RoundedRectangle(cornerRadius: 10)
//                    .fill(Color(UIColor.systemBackground))
//                    .shadow(color: Color(UIColor.systemGray4).opacity(0.5), radius: 5, x: 0, y: 2)
//            )
//            .padding(.horizontal)
//        }
//        .background(Color(UIColor.systemGroupedBackground).edgesIgnoringSafeArea(.all))
//        .alert(isPresented: $showAlert) {
//            Alert(title: Text(alertMessage))
//        }
//    }
//}

//struct LibrarianBookRequestCard: View {
//    @State private var showAlert = false
//    @State private var alertMessage = ""
//
//    var body: some View {
//        VStack {
//            VStack(alignment: .leading, spacing: 12) {
//                Text("Book Request")
//                    .font(.headline)
//                    .padding(.bottom, 5)
//                    .foregroundColor(.primary)
//                
//                HStack {
//                    Text("Issuer:")
//                        .font(.subheadline)
//                        .fontWeight(.medium)
//                        .foregroundColor(.primary)
//                    Spacer()
//                    Text("Piyush Saini")
//                        .foregroundColor(.secondary)
//                }
//                HStack {
//                    Text("Book Name:")
//                        .font(.subheadline)
//                        .fontWeight(.medium)
//                        .foregroundColor(.primary)
//                    Spacer()
//                    Text("Harry Potter")
//                        .foregroundColor(.secondary)
//                }
//                
//                Divider()
//                    .background(Color.primary)
//                
//                HStack(spacing: 20) {
//                    Button(action: {
//                        alertMessage = "Request accepted"
//                        showAlert = true
//                    }) {
//                        Text("Accept")
//                            .frame(minWidth: 140, minHeight: 44)
//                            .background(
//                                LinearGradient(gradient: Gradient(colors: [Color(hex: "#744240"), Color(hex: "#5D3534")]),
//                                               startPoint: .topLeading, endPoint: .bottomTrailing)
//                            )
//                            .foregroundColor(.white)
//                            .cornerRadius(8)
//                            .font(.headline)
//                    }
//                    Button(action: {
//                        alertMessage = "Request rejected"
//                        showAlert = true
//                    }) {
//                        Text("Reject")
//                            .frame(minWidth: 140, minHeight: 44)
//                            .background(
//                                LinearGradient(gradient: Gradient(colors: [Color(hex: "#744240"), Color(hex: "#5D3534")]),
//                                               startPoint: .topLeading, endPoint: .bottomTrailing)
//                            )
//                            .foregroundColor(.white)
//                            .cornerRadius(8)
//                            .font(.headline)
//                    }
//                }
//                .padding(.top, 10)
//                .frame(maxWidth: .infinity, alignment: .center) // Center the buttons
//            }
//            .padding()
//            .background(
//                RoundedRectangle(cornerRadius: 10)
//                    .fill(Color(UIColor.systemBackground))
//                    .overlay(
//                        RoundedRectangle(cornerRadius: 10)
//                            .stroke(Color(hex: "#744240").opacity(0.3), lineWidth: 1)
//                    )
//                    .shadow(color: Color(UIColor.systemGray4).opacity(0.5), radius: 5, x: 0, y: 2)
//            )
//            .padding(.horizontal)
//        }
//        .background(Color(UIColor.systemGroupedBackground).edgesIgnoringSafeArea(.all))
//        .alert(isPresented: $showAlert) {
//            Alert(title: Text(alertMessage))
//        }
//    }
//}
//
//extension Color {
//    init(hex: String) {
//        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
//        var int: UInt64 = 0
//        Scanner(string: hex).scanHexInt64(&int)
//        let a, r, g, b: UInt64
//        switch hex.count {
//        case 3: // RGB (12-bit)
//            (a, r, g, b) = (255, (int >> 8 * 17), (int >> 4 & 0xF * 17), (int & 0xF * 17))
//        case 6: // RGB (24-bit)
//            (a, r, g, b) = (255, (int >> 16), (int >> 8 & 0xFF), (int & 0xFF))
//        case 8: // ARGB (32-bit)
//            (a, r, g, b) = ((int >> 24), (int >> 16 & 0xFF), (int >> 8 & 0xFF), (int & 0xFF))
//        default:
//            (a, r, g, b) = (255, 0, 0, 0)
//        }
//        self.init(
//            .sRGB,
//            red: Double(r) / 255,
//            green: Double(g) / 255,
//            blue: Double(b) / 255,
//            opacity: Double(a) / 255
//        )
//    }
//}


struct LibrarianBookRequestCard: View {
    @State private var showAlert = false
    @State private var alertMessage = ""
    @StateObject var issueActionManger = IssueActionManager()
    @EnvironmentObject var issueRequestManager:LibrarianIssueRequestManager
    var book:LibrarianIssueBook
    @State var action:IssueStatus = .pending
//    var body: some View {
        //        VStack {
        //            VStack(alignment: .leading, spacing: 12) {
        //                Text("Book Request")
        //                    .font(.headline)
        //                    .padding(.bottom, 5)
        //
        //                HStack {
        //                    Text("Issuer:")
        //                        .font(.subheadline)
        //                        .fontWeight(.medium)
        //                    Spacer()
        //                    Text("\(book.user.name)")
        //                        .foregroundColor(.secondary)
        //                }
        //                HStack {
        //                    Text("Book Name:")
        //                        .font(.subheadline)
        //                        .fontWeight(.medium)
        //                    Spacer()
        //                    Text("\(book.book.title)")
        //                        .foregroundColor(.secondary)
        //                }
        //
        //                Divider()
        //
        //                HStack(spacing: 20) {
        //                    Button(action: {
        //                        alertMessage = "Request accepted"
        //                        showAlert = true
        //                    }) {
        //                        Text("Accept")
        //                            .frame(minWidth: 140, minHeight: 44)
        //                            .background(
        //                               buttonBrownGradient
        //                            )
        //                            .foregroundColor(.white)
        //                            .cornerRadius(8)
        //                            .font(.headline)
        //                    }
        //                    Button(action: {
        //                        alertMessage = "Request rejected"
        //                        showAlert = true
        //                    }) {
        //                        Text("Reject")
        //                            .frame(minWidth: 140, minHeight: 44)
        //                            .background(
        //                                buttonBrownGradient
        //                            )
        //                            .foregroundColor(.white)
        //                            .cornerRadius(8)
        //                            .font(.headline)
        //                    }
        //                }
        //                .padding(.top, 10)
        //                .frame(maxWidth: .infinity, alignment: .center) // Center the buttons
        //            }
        //            .padding()
        //            .background(
        //                RoundedRectangle(cornerRadius: 10)
        //                    .fill(Color(UIColor.systemGray6))
        //                    .overlay(
        //                        RoundedRectangle(cornerRadius: 10)
        //                            .stroke(Color(.separator), lineWidth: 1)
        //                    )
        //            )
        //            .padding(.horizontal)
        //        }
        //        .alert(isPresented: $showAlert) {
        //            Alert(title: Text(alertMessage))
        //        }
        var body: some View {
                VStack {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Book Request")
                            .font(.headline)
                            .padding(.bottom, 5)

                        HStack {
                            Text("Issuer:")
                                .font(.subheadline)
                                .fontWeight(.medium)
                            Spacer()
                            Text("\(book.user.name)")
                                .foregroundColor(.secondary)
                        }
                        HStack {
                            Text("Book Name:")
                                .font(.subheadline)
                                .fontWeight(.medium)
                            Spacer()
                            Text("\(book.book.title)")
                                .foregroundColor(.secondary)
                        }

                        Divider()

                        HStack(spacing: 20) {
                            Button(action: {
                                alertMessage = "Do you want to accept the request?"
                                action = .approved
                                showAlert = true
                            }) {
                                Text("Accept")
                                    .frame(minWidth: 140, minHeight: 44)
                                    .background(buttonBrownGradient)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                                    .font(.headline)
                            }
                            Button(action: {
                                alertMessage = "Do you want to reject the request?"
                                action = .rejected
                                showAlert = true
                            }) {
                                Text("Reject")
                                    .frame(minWidth: 140, minHeight: 44)
                                    .background(buttonBrownGradient)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                                    .font(.headline)
                            }
                        }
                        .padding(.top, 10)
                        .frame(maxWidth: .infinity, alignment: .center) // Center the buttons
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color(UIColor.systemGray6))
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color(.separator), lineWidth: 1)
                            )
                    )
                    .padding(.horizontal)
                }
                .alert(isPresented: $showAlert) {
                    Alert(
                        title: Text("Confirmation"),
                        message: Text(alertMessage),
                        primaryButton: .default(Text("Confirm")) {
                            Task{
                                do{
                                    try await issueActionManger.issueActionMnager(actionManager: ActionManager(id: book.id, status: action), of: issueRequestManager)
                                }
                            }
                        },
                        secondaryButton: .cancel()
                    )
                }
            }
    }

//extension Color {
//    init(hex: String) {
//        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
//        var int: UInt64 = 0
//        Scanner(string: hex).scanHexInt64(&int)
//        let a, r, g, b: UInt64
//        switch hex.count {
//        case 3: // RGB (12-bit)
//            (a, r, g, b) = (255, (int >> 8 * 17), (int >> 4 & 0xF * 17), (int & 0xF * 17))
//        case 6: // RGB (24-bit)
//            (a, r, g, b) = (255, (int >> 16), (int >> 8 & 0xFF), (int & 0xFF))
//        case 8: // ARGB (32-bit)
//            (a, r, g, b) = ((int >> 24), (int >> 16 & 0xFF), (int >> 8 & 0xFF), (int & 0xFF))
//        default:
//            (a, r, g, b) = (255, 0, 0, 0)
//        }
//        self.init(
//            .sRGB,
//            red: Double(r) / 255,
//            green: Double(g) / 255,
//            blue: Double(b) / 255,
//            opacity: Double(a) / 255
//        )
//    }
//}

//struct LibrarianBookRequestCard_Previews: PreviewProvider {
//    static var previews: some View {
//        Group {
//            LibrarianBookRequestCard()
//                .previewLayout(.sizeThatFits)
//                .padding()
//                .background(Color(UIColor.systemGroupedBackground))
//                .environment(\.colorScheme, .light)
//            
//            LibrarianBookRequestCard()
//                .previewLayout(.sizeThatFits)
//                .padding()
//                .background(Color(UIColor.systemGroupedBackground))
//                .environment(\.colorScheme, .dark)
//        }
//    }
//}

//#Preview {
//    LibrarianBookRequestCard()
//}
