//
//  MemberFavouritesView.swift
//  pustak
//
//  Created by Abhay(IOS) on 12/06/24.
//

import SwiftUI

struct MemberFavouritesView: View {
    @EnvironmentObject var userSession:UserSession
    @EnvironmentObject var wishlistManager:MemberGetWishlist
    @EnvironmentObject var wishlistActionManager:MemberWishlistManager
    @State var searchableText = ""
    var filterbooks: [Books]{
        if searchableText.isEmpty{
            return wishlistManager.wishlist
        }
        else{
//            return  bookManager.books.filter{$0.title.localizedCaseInsensitiveContains(searchableText)}
            return wishlistManager.wishlist.filter{$0.title.localizedCaseInsensitiveContains(searchableText)}
        }
    }
    var body: some View {
        NavigationStack{
            ScrollView {
                if(wishlistManager.isLoading)
                {
                    ProgressView()
                }
                else{
                    VStack(spacing: 16) {
                        ForEach(filterbooks) { book in
                            NavigationLink(destination:MemberBookInfoView(book: book)){
                                HStack {
                                    BookCoverView(bookName: book.title, authorName: book.author)
                                        .frame(width:100,height: 150)
                                    
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text(book.title)
                                            .font(.title2)
                                            .fontWeight(.semibold)
                                            .foregroundColor(.primary)
                                            .multilineTextAlignment(.leading)
                                            .lineLimit(2)
                                        
                                        Text("by \(book.author)")
                                            .font(.title3)
                                            .foregroundColor(.secondary)
                                        
                                        Spacer()
                                            
                                            Button(action: {
                                                Task{
                                                    do{
                                                        try await wishlistActionManager.removeFromWishlist(with: book, userId: userSession.uId, libraryId: getSelectedLibrary(), of: wishlistManager)                                                }
                                            }
                                            }) {
                                                MemberCustomButton(content: "Remove", isActive: false)
                                            }
                                    }
                                    .padding(.leading)
                                    
                                    Spacer()
                                }
                            }
                            .padding()
                            .background(
                                LinearGradient(gradient: Gradient(colors: [Color(UIColor.systemBackground), Color(UIColor.secondarySystemBackground)]),
                                               startPoint: .topLeading, endPoint: .bottomTrailing)
                            )
                            .cornerRadius(10)
                            .shadow(radius: 5)
                        }
                    }
                    .padding()
                    
                }
            }
            .navigationTitle("Favourites")
            .searchable(text: $searchableText, prompt: "Search")
        }
    }
}

//#Preview {
//    MemberFavouritesView()
//}
