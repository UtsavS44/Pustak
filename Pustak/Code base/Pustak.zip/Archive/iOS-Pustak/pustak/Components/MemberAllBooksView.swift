//
//  MemberAllBooksView.swift
//  pustak
//
//  Created by Abhay(IOS) on 13/06/24.
//

import SwiftUI

import SwiftUI

struct MemberAllBooksView: View {
    @EnvironmentObject var bookManager:LibrarianFetchBookManager
    @State var searchableText = ""
    var filterbooks: [Books]{
        if searchableText.isEmpty{
            return bookManager.books
        }
        else{
            return  bookManager.books.filter{$0.title.localizedCaseInsensitiveContains(searchableText)}
        }
    }
    var body: some View {
        ScrollView{
            VStack{
                ForEach(filterbooks){ book in
                    MemberBookCard(book: book)
                        .environmentObject(bookManager)
                }
            }
        }
        .navigationTitle("All Books")
        .searchable(text: $searchableText, prompt: "Search books")

    }
}

//#Preview {
//    MemberAllBooksView()
//}
