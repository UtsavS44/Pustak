//
//  MemberBookCard.swift
//  pustak
//
//  Created by Abhay(IOS) on 12/06/24.
//

import SwiftUI

struct MemberBookCard: View {
    @EnvironmentObject var bookManager:LibrarianFetchBookManager
    var book:Books
    var body: some View {
        NavigationLink(destination: MemberBookInfoView(book:book)) {
            HStack(spacing: 16) {
                BookCoverView(bookName: book.title, authorName: book.author)
                    .frame(width: 50,height: 100)
                    .padding(.vertical,0)
                    .padding(.leading,15)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("\(book.title)")
                        .font(.title2)
                        .foregroundColor(.primary)
                    Text("\(book.author)")
                        .font(.headline)
                        .foregroundColor(.secondary)
                }
                Spacer()
            }
            .frame(maxWidth: .infinity)
            .background(Color(uiColor: .systemGray6))
            .cornerRadius(10)
            .padding()
        }
    }
}

//#Preview {
//    MemberBookCard()
//}
