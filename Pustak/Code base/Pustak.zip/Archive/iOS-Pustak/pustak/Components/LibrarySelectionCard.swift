//
//  LibrarySelectionCard.swift
//  pustak
//
//  Created by Abhay(IOS) on 12/06/24.
//

import SwiftUI

struct LibrarySelectionCard: View {
    let library: Library
    let isSelected: Bool

    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(library.libraryName)
                    .font(.headline)
                    .foregroundColor(isSelected ? Color.customBrown : Color.customBrown)
                Text(library.address)
                    .font(.subheadline)
                    .foregroundColor(isSelected ? Color.customBrown : Color.customBrown)
            }
            Spacer()
            if isSelected {
                Image(systemName: "circle.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 24)
                    .foregroundColor(Color.customBrown)
            }
        }
        .padding()
        .background(Color.customBrown.opacity(0.1))
        .cornerRadius(15)
        .overlay(
            RoundedRectangle(cornerRadius: 15)
                .stroke(isSelected ? Color.customBrown : Color.customBrown.opacity(0.15) , lineWidth: 2)
        )
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity)
    }
}

//#Preview {
//    LibrarySelectionCard()
//}
