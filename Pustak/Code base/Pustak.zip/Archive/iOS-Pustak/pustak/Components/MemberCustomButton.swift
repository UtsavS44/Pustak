//
//  MemberCustomButton.swift
//  pustak
//
//  Created by Abhay(IOS) on 12/06/24.
//

import SwiftUI

struct MemberCustomButton: View {
    var content: String
    var activeColor = Color(#colorLiteral(red: 0.4862745098, green: 0.2470588235, blue: 0.2431372549, alpha: 1))
    var inActiveColor = Color(uiColor: .systemRed)
    var isActive:Bool = true
    var body: some View {
        if(isActive == true){
            Text(content)
                .font(.subheadline)
                .fontWeight(.bold)
                .frame(alignment: .center)
                .padding(.vertical)
                .frame(maxWidth: .infinity)
                .frame(height: 40)
                .foregroundColor(.white)
                .background(buttonBrownGradient) // Using specified color
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 3)
        }
        else{
            Text(content)
                .font(.subheadline)
                .fontWeight(.bold)
                .frame(alignment: .center)
                .padding(.vertical)
                .frame(maxWidth: .infinity)
                .frame(height: 40)
                .foregroundColor(.white)
                .background(inActiveColor) // Using specified color
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 3)
        }
        
    }
}


