//
//  PendingRequestCard.swift
//  pustak
//
//  Created by Abhay(IOS) on 13/06/24.
//

import SwiftUI

struct PendingRequestCard: View {
    var book:MemberIssueBook
    var body: some View {
            HStack {
                BookCoverView(bookName: book.book.title, authorName: book.book.author)
                    .frame(width: 70, height: 100)
                    .cornerRadius(10)
                    .shadow(radius: 5)
                
                VStack(alignment: .leading, spacing: 8) {
                    Spacer()
                    Text(book.book.title)
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)
                    
                    Text("by \(book.book.author)")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Spacer()
                }
                Spacer()
            }
            .frame(height: 120)
//            .background(
//                RoundedRectangle(cornerRadius: 10, style: .continuous)
//                    .fill(Color(UIColor.secondarySystemBackground))
//                    .shadow(color: Color(UIColor.systemGray4).opacity(0.5), radius: 5, x: 0, y: 2)
//            )
        }
}

//#Preview {
//    PendingRequestCard()
//}
