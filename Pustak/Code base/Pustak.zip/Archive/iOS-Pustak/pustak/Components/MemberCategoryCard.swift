//
//  MemberCategoryCard.swift
//  pustak
//
//  Created by Abhay(IOS) on 12/06/24.
//

import SwiftUI

struct MemberCategoryCard: View {
    var category:Genre
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(buttonBrownGradient)
                .frame(height: 100)
                .shadow(radius: 5)
            
            Text(category.rawValue)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
        }
        .padding(.horizontal, 10)
    }
}

//#Preview {
//    MemberCategoryCard()
//}
