//
//  IssueHistoryView.swift
//  pustak
//
//  Created by Abhay(IOS) on 14/06/24.
//

import SwiftUI

struct IssueHistoryView: View {
    @EnvironmentObject var getHistoryBooksManager:GetIssueBookManager
    var returnedBooks: [MemberIssueBook] {
            getHistoryBooksManager.issuedBooks.filter { $0.returned }
        }
    var body: some View {
        List{
        if(returnedBooks.isEmpty){
            Text("No books have been returned yet")
                .font(.title3)
                .foregroundStyle(buttonBrownGradient)
        }
        else{
                ForEach(returnedBooks){ book in
                        MemberMyBookCard(book: book)
                    }
            }
        }
        .navigationTitle("Issue History")
    }
}

#Preview {
    IssueHistoryView()
}
