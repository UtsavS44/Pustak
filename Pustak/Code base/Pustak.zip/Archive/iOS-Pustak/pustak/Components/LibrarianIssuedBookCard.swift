//
//  LibrarianIssuedBookCard.swift
//  pustak
//
//  Created by Abhay(IOS) on 14/06/24.
//

import SwiftUI

struct LibrarianIssuedBookCard: View {
    var book: LibrarianIssueBook

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(book.book.title)
                .font(.headline)
                .padding(.bottom, 2)
                .foregroundColor(.primary)

            HStack {
                Text("Issuer:")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                Spacer()
                Text(book.user.name)
                    .foregroundColor(.secondary)
            }

            Divider()
                .padding(.vertical, 4)

            HStack {
                Spacer()
                Text("Tap for more details")
                    .font(.footnote)
                    .foregroundColor(.blue)
                Spacer()
            }
            .padding(.top,5)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(UIColor.secondarySystemBackground))
                .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
        )
        .padding()
    }
}

