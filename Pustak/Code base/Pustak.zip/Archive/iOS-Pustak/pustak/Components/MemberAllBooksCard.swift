//
//  MemberAllBooksCard.swift
//  pustak
//
//  Created by Abhay(IOS) on 13/06/24.
//

import SwiftUI

struct MemberAllBooksCard: View {
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .fill(buttonBrownGradient)
                .frame(height: 100)
                .shadow(radius: 5)
            
            Text("All Books")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.white)
        }
        .padding(.horizontal, 10)
    }
}

//#Preview {
//    MemberAllBooksCard()
//}
