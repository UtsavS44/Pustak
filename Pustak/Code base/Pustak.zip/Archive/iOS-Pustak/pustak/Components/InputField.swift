import Foundation
import SwiftUI


enum InputTypes: String, CaseIterable{
    case email
    case password
    case name
    case mobNo
}
struct InputField: View {
    @Binding var text: String
    var placeholder: String
    var cornerRadius: CGFloat
    var onEditingChanged: (Bool) -> Void = {_ in}
    var onCommit: () -> Void = {}
    var isSecure: Bool = false
    var inputType: InputTypes = .name
    var height:CGFloat = 50
    
    var body: some View {
//        if(!isSecure){
//            TextField(placeholder, text: $text)
//                .keyboardType(keyboardType(inputType))
//                .autocorrectionDisabled()
//                .textInputAutocapitalization(.never)
//                .frame(height: CGFloat(integerLiteral: height))
//                .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
//        }else{
//            SecureField(placeholder, text: $text)
//                .frame(height: CGFloat(integerLiteral: height))
//                .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
//            
//        }
        
        if !isSecure {
                    TextField(placeholder, text: $text)
                        .keyboardType(keyboardType(inputType))
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                        .padding(.horizontal, 12)
                        .frame(height: height)
                        .cornerRadius(cornerRadius)
                        .overlay(
                            RoundedRectangle(cornerRadius: cornerRadius)
                                .stroke(Color(.separator), lineWidth: 1)
                        )
                        .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 2)
                        .padding(.bottom, 5)
                } else {
                    SecureField(placeholder, text: $text)
                        .padding(.horizontal, 12)
                        .frame(height: height)
                        .cornerRadius(cornerRadius)
                        .overlay(
                            RoundedRectangle(cornerRadius: cornerRadius)
                                .stroke(Color(.separator), lineWidth: 1)
                        )
                        .background(Color.clear)
                }
    }
    private func keyboardType(_ inputType: InputTypes) -> UIKeyboardType {
        switch inputType {
        case .email:
                .emailAddress
        case .password, .name:
                .default
        case .mobNo:
                .decimalPad
        }
        
    }
}


//#Preview{
//    InputField()
//}
